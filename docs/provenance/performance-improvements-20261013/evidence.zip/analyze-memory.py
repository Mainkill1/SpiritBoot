"""Qualify seven complete native pairs before reporting memory-pin timings."""
import csv
import hashlib
import importlib.util
import json
import math
import re
import statistics as st
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location('shared_qualification', ROOT/'analyze-final.py')
shared = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(shared)
require = shared.require
BIOS = {
    'baseline': '1ed234ebaf8e95937225c3002b6eac26257b0f3d1ff8f3d6a3aabd464955fb0b',
    'validated': '647f9d6fc74a411cba716e3c0343b90300fc40ea9a8daf0b64bf8a5e9cd30e75',
}
EXE = shared.EXE
FIXTURE = '65da3568167cd7e25eec3da4baaffbe65c7fae931078659885297e657412a705'
SOURCE_TREE = '92af6b47b5157031931454021407420c5f9920a8'
OUTPUTS = ['memory-microbenchmarks.csv', 'memory-interpretation.txt']


def receipt(path, side):
    launch = json.loads((path/'launch.json').read_text(encoding='utf-8-sig'))
    result = json.loads((path/'result.json').read_text(encoding='utf-8-sig'))
    require(result['exited'] is True and type(result['exitCode']) is int and result['exitCode'] == 0,
            f'abnormal/incomplete process: {path.name}')
    require(type(launch['session']) is int and launch['session'] > 0,
            f'noninteractive session: {path.name}')
    for field, expected in [('biosSha256', BIOS[side]), ('exeSha256', EXE), ('probeSha256', FIXTURE)]:
        require(launch[field].lower() == expected, f'{field} mismatch: {path.name}')
    elapsed = result['elapsedSeconds']
    require(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 < elapsed < 180,
            f'invalid elapsed time: {path.name}')
    ended = datetime.fromisoformat(result['utc'].replace('Z', '+00:00'))
    require(ended.utcoffset() == timedelta(0), f'non-UTC timestamp: {path.name}')
    return dict(path=path.name, started=ended-timedelta(seconds=elapsed), ended=ended,
                elapsed_seconds=elapsed, session=launch['session'], bios_sha256=BIOS[side],
                exe_sha256=EXE, fixture_sha256=FIXTURE,
                serial_sha256=hashlib.sha256((path/'serial.log').read_bytes()).hexdigest())


def validate_intervals(records):
    ordered = sorted(records.values(), key=lambda r:r['started'])
    require(len({r['session'] for r in ordered}) == 1, 'session changed within campaign')
    for before, after in zip(ordered, ordered[1:]):
        require(before['ended'] <= after['started'],
                f'overlapping runs: {before["path"]}, {after["path"]}')
    for pair in range(7):
        first, second = ('baseline', 'validated') if pair % 2 == 0 else ('validated', 'baseline')
        require(records[pair, first]['ended'] <= records[pair, second]['started'],
                f'pair {pair} order does not alternate')


def stats(a, b):
    require(len(a) == len(b) == 7, 'seven pairs required')
    ma, mb = st.median(a), st.median(b)
    return dict(trials=7, baseline_median_us=ma, candidate_median_us=mb,
                baseline_mean_us=st.mean(a), candidate_mean_us=st.mean(b),
                ratio=mb/ma if ma else None, reduction_percent=100*(1-mb/ma) if ma else None,
                baseline_min_us=min(a), baseline_max_us=max(a),
                candidate_min_us=min(b), candidate_max_us=max(b),
                faster_pairs=sum(y<x for x,y in zip(a,b)), slower_pairs=sum(y>x for x,y in zip(a,b)),
                direction='faster' if max(b)<min(a) else 'slower' if min(b)>max(a) else 'overlap',
                **{f'baseline_pair{i}_us':v for i,v in enumerate(a)},
                **{f'candidate_pair{i}_us':v for i,v in enumerate(b)})


def analyze(root):
    paths = {}
    for path in sorted((root/'results').glob('probe-memory-*')):
        match = re.fullmatch(r'probe-memory-([0-6])-(baseline|validated)-\d{8}-\d{6}', path.name)
        require(match is not None, f'unrecognized memory run: {path.name}')
        key = int(match[1]), match[2]
        require(key not in paths, f'duplicate pair/side: {key}')
        paths[key] = path
    expected = {(p,s) for p in range(7) for s in BIOS}
    require(set(paths)==expected, f'incomplete memory campaign: {len(paths)}/14; missing={sorted(expected-set(paths))}')
    records, values = {}, {}
    for key, path in paths.items():
        records[key] = receipt(path, key[1])
        log = (path/'serial.log').read_text(encoding='utf-8-sig')
        values[key] = shared.parse_micro(log)
        records[key]['counter_frequency_hz'] = int(shared.one(r'^# PERF-META version=1 clock=KeQueryPerformanceCounter frequency=(\d+) samples=3$', log))
    validate_intervals(records)
    rows = [dict(workload=name, **stats([values[p,'baseline'][name] for p in range(7)],
                                      [values[p,'validated'][name] for p in range(7)]))
            for name in sorted(values[0,'baseline'])]
    return dict(validated=True, completed_runs=14, pairs=7, workloads_per_run=40,
                samples_per_run=118, tap_checks_per_run=41, candidate_source_tree=SOURCE_TREE,
                bios=BIOS, exe_sha256=EXE, fixture_sha256=FIXTURE,
                analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                shared_parser_sha256=hashlib.sha256((ROOT/'analyze-final.py').read_bytes()).hexdigest(),
                nonoverlap=True, alternating_order=True, exact_checksums=True,
                formulas='Each run uses median(ticks*1e6/frequency/iterations) over its samples; comparison uses median of seven run medians. Ratio is candidate/baseline. Range direction requires nonoverlapping min/max, as analyze.py.',
                limitations='Synthetic microbenchmarks only. Observed ranges are descriptive, not confidence intervals. No claim of equivalent Complex performance or improved relocation behavior.',
                records=[dict(pair=p, side=s, **{k:v.isoformat() if isinstance(v,datetime) else v for k,v in r.items()})
                         for (p,s),r in sorted(records.items())], rows=rows)


def write_outputs(report, root):
    with (root/OUTPUTS[0]).open('w',newline='') as output:
        writer=csv.DictWriter(output, fieldnames=list(report['rows'][0]));writer.writeheader();writer.writerows(report['rows'])
    targets=[r for r in report['rows'] if r['workload'].startswith('pin-')]
    primary=next(r for r in targets if r['workload']=='pin-4096')
    lines=[f"Validated seven matched pairs (14 runs), each with 40 workloads, 118 exact samples/checksums and 41 passing TAP checks.",
           f"pin-4096: {primary['baseline_median_us']:.3f} -> {primary['candidate_median_us']:.3f} us per lock/unlock pair ({primary['reduction_percent']:.2f}% less time; ratio {primary['ratio']:.4f}); faster in {primary['faster_pairs']}/7 pairs, observed range direction: {primary['direction']}.",
           '', 'Pin workload details:']
    for r in targets:
        lines.append(f"{r['workload']}: {r['baseline_median_us']:.3f} -> {r['candidate_median_us']:.3f} us; ratio {r['ratio']:.4f}; faster pairs {r['faster_pairs']}/7; {r['direction']} ranges")
    other=[r for r in report['rows'] if not r['workload'].startswith('pin-') and r['direction']!='overlap']
    lines+=['','Unrelated workloads with separated observed ranges (reported, not attributed to pin changes):']
    lines += [f"{r['workload']}: ratio {r['ratio']:.4f}; {r['direction']}" for r in other] or ['None.']
    lines+=['',report['formulas'], report['limitations'],
            'The previous consecutive-frame candidate was rejected after native slowdown. This candidate removes duplicate eligibility checks without relying on mapping geometry. Full API qualification is a separate receipt set.']
    (root/OUTPUTS[1]).write_text('\n'.join(lines)+'\n')
    (root/'memory-report.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':
    try:
        report=analyze(ROOT);write_outputs(report,ROOT)
        print(json.dumps({k:report[k] for k in ['validated','completed_runs','pairs','workloads_per_run','samples_per_run']},indent=2))
    except (ValueError,KeyError,OSError,TypeError,IndexError) as error:
        for name in OUTPUTS:(ROOT/name).unlink(missing_ok=True)
        (ROOT/'memory-report.json').write_text(json.dumps({'validated':False,'error':str(error)},indent=2)+'\n')
        raise SystemExit(f'MEMORY QUALIFICATION REFUSED: {error}')
