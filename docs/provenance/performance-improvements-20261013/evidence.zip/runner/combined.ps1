$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$s='C:\xemu-lab\incoming\perf-improve-20261013'
$bioses=@{baseline='C:\xemu-lab\incoming\doa-save-20261013\save-path-candidate64.bin';combined=($s+'\hotpaths64.bin')}
& ($s+'\run-one.ps1') -Profile combined-apc -Bios $bioses['combined'] -Fixture ($s+'\timer-apc-mode.iso') -Port 60200
$port=60202
foreach($fixture in @('api-leaf-performance','kernel-performance-portable','stream-timing','sync-cost')){
 for($pair=0;$pair -lt 3;$pair++){
  $order=if($pair%2 -eq 0){@('baseline','combined')}else{@('combined','baseline')}
  foreach($side in $order){
   & ($s+'\run-one.ps1') -Profile ('final-'+$fixture+'-'+$pair+'-'+$side) -Bios $bioses[$side] -Fixture ($s+'\'+$fixture+'.iso') -Port $port
   $port+=2
  }
 }
}
'complete'|Set-Content ($s+'\combined-complete.txt')
