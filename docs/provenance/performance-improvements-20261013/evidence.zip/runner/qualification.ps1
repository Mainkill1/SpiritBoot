$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$s='C:\xemu-lab\incoming\perf-improve-20261013'
$bioses=@{baseline='C:\xemu-lab\incoming\doa-save-20261013\save-path-candidate64.bin';pin=($s+'\pin64.bin');des=($s+'\des-final64.bin');complex='C:\xemu-lab\XEMU FILES\BIOS\Complex_4627v1.03.bin'}
$port=60110
foreach($side in @('pin','des')){
 & ($s+'\run-one.ps1') -Profile ($side+'-api') -Bios $bioses[$side] -Fixture ($s+'\api-leaf-performance.iso') -Port $port
 $port+=2
}
for($pair=0;$pair -lt 7;$pair++){
 $order=if($pair%2 -eq 0){@('baseline','pin','des')}else{@('des','pin','baseline')}
 foreach($side in $order){
  & ($s+'\run-one.ps1') -Profile ('micro-'+$pair+'-'+$side) -Bios $bioses[$side] -Fixture ($s+'\kernel-performance-portable.iso') -Port $port
  $port+=2
 }
}
foreach($side in @('baseline','complex')){
 & ($s+'\run-one.ps1') -Profile ('io-policy-'+$side) -Bios $bioses[$side] -Fixture ($s+'\completion-policy-probe.iso') -Port $port
 $port+=2
}
'complete'|Set-Content ($s+'\qualification-complete.txt')
