$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$s='C:\xemu-lab\incoming\perf-improve-20261013'
& ($s+'\run-one.ps1') -Profile apc-baseline -Bios 'C:\xemu-lab\incoming\doa-save-20261013\save-path-candidate64.bin' -Fixture ($s+'\timer-apc-mode.iso') -Port 60100
& ($s+'\run-one.ps1') -Profile apc-complex -Bios 'C:\xemu-lab\XEMU FILES\BIOS\Complex_4627v1.03.bin' -Fixture ($s+'\timer-apc-mode.iso') -Port 60102
'complete'|Set-Content ($s+'\apc-baseline-complete.txt')
