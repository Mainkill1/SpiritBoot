$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$s='C:\xemu-lab\incoming\perf-improve-20261013'
while((Get-ScheduledTask CodexPerfImprove20261013).State -eq 'Running'){Start-Sleep -Seconds 2}
if(!(Test-Path ($s+'\combined-complete.txt'))){throw 'Combined gate incomplete'}
if(Get-Process xemu -ErrorAction SilentlyContinue){throw 'Unexpected xemu process'}
$bioses=@{baseline='C:\xemu-lab\incoming\doa-save-20261013\save-path-candidate64.bin';validated=($s+'\pin-validated64.bin')}
& ($s+'\run-one.ps1') -Profile validated-api -Bios $bioses['validated'] -Fixture ($s+'\api-leaf-performance.iso') -Port 60300
$port=60302
for($pair=0;$pair -lt 7;$pair++){
 $order=if($pair%2 -eq 0){@('baseline','validated')}else{@('validated','baseline')}
 foreach($side in $order){
  & ($s+'\run-one.ps1') -Profile ('memory-'+$pair+'-'+$side) -Bios $bioses[$side] -Fixture ($s+'\kernel-performance-portable.iso') -Port $port
  $port+=2
 }
}
'complete'|Set-Content ($s+'\memory-complete.txt')
