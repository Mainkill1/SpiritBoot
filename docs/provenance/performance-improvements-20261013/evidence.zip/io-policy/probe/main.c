/* SPDX-License-Identifier: GPL-2.0-or-later
 * Owned data, public read parameters observed in Forza; no game content. */
#include <windows.h>
#include <xboxkrnl/xboxkrnl.h>
#include <stdlib.h>
#include "regression.h"
#define BLOCK 16384
#define READS 1024
#define FILE_BYTES (16*1024*1024)
static unsigned char *data;
static IO_STATUS_BLOCK io;
static volatile ULONG callbacks,errors;
static ULONG wanted;
static PVOID pressure[1024];
static ULONG submit[READS],complete[READS],after_return[READS];
static UCHAR pattern(ULONG p){return (UCHAR)(p^(p>>8)^(p>>16));}
static void NTAPI done(DWORD error,DWORD bytes,PVOID context){if(error || bytes!=wanted || context!=&io)errors++;callbacks++;}
static int cmp(const void *a,const void *b){ULONG x=*(ULONG *)a,y=*(ULONG *)b;return x<y?-1:x>y;}
static ULONG available(void){MM_STATISTICS s={.Length=sizeof(s)};return MmQueryStatistics(&s)==0?s.AvailablePages:0;}
/* Each mode has identical offsets, sizes, buffers and byte verification.
 * Mode 0 preserves the original zero-delay APC polling policy.
 * Mode 1 blocks alertably for the I/O APC; mode 2 waits on an event, no APC. */
static HANDLE completion_event;
static const char *mode_name[]={"apc-poll", "apc-block", "event-block"};
static void run(HANDLE file,unsigned phase,unsigned repeat,unsigned mode){
 ULONGLONG freq=KeQueryPerformanceFrequency(),sum=0,sumdone=0,sumafter=0;ULONG mismatch=0,pending=0,zero=0,noyield=0;
 ULONG pages=available(),before_tick=GetTickCount();
 ULONG at_return=0, short_count=0, long_count=0, short_us=0, long_us=0;
 ULONG waits=0,apc_waits=0,timeouts=0,other_waits=0;
 ULONGLONG loop_start=KeQueryPerformanceCounter();
 for(unsigned n=0;n<READS;n++) {
  ULONG length=n%2==0?512:((n/2)%15+1)*512;
  ULONG offset=((n*7919U)%(FILE_BYTES/BLOCK))*BLOCK+(n%7)*512;
  unsigned char *buffer=data+(n%4)*512;
  memset(buffer,0xcc,length);io.Status=0;io.Information=0;callbacks=0;wanted=length;
  if(mode==2 && NtClearEvent(completion_event)!=STATUS_SUCCESS)
   regression_require(0,"clear completion event before buffer reuse");
  LARGE_INTEGER at={.QuadPart=offset};ULONGLONG start=KeQueryPerformanceCounter();
  NTSTATUS result=NtReadFile(file,mode==2?completion_event:NULL,mode==2?NULL:(PIO_APC_ROUTINE)NtUserIoApcDispatcher,mode==2?NULL:(PVOID)done,&io,buffer,length,&at);
  ULONGLONG returned=KeQueryPerformanceCounter();pending+=result==STATUS_PENDING;
  at_return+=io.Status==0 && io.Information==length;
  if(!NT_SUCCESS(result))regression_require(0,"bounded read accepted");
  DWORD deadline=GetTickCount()+5000;
  if(mode==2) {
   LARGE_INTEGER t={.QuadPart=-50000000};
   NTSTATUS wait=NtWaitForSingleObjectEx(completion_event,UserMode,FALSE,&t);
   waits++;zero+=wait==STATUS_SUCCESS;timeouts+=wait==STATUS_TIMEOUT;
   if(wait!=STATUS_SUCCESS)regression_require(0,"event completion before timeout");
  } else {
   while(!callbacks && (LONG)(deadline-GetTickCount())>0) {
    LARGE_INTEGER t={.QuadPart=mode==0?0:-50000000};
    NTSTATUS wait=KeDelayExecutionThread(UserMode,TRUE,&t);
    waits++;zero+=wait==STATUS_SUCCESS;noyield+=wait==0x40000024;
    apc_waits+=wait==STATUS_USER_APC;timeouts+=wait==STATUS_TIMEOUT;
    other_waits+=wait!=STATUS_SUCCESS && wait!=0x40000024 && wait!=STATUS_USER_APC && wait!=STATUS_TIMEOUT;
   }
  }
  ULONGLONG end=KeQueryPerformanceCounter();
  if(callbacks!=(mode==2?0:1))regression_require(0,"exact callback count before buffer reuse");
  if(io.Status!=STATUS_SUCCESS || io.Information!=length)regression_require(0,"exact successful completion before buffer reuse");
  submit[n]=(ULONG)((returned-start)*1000000/freq);complete[n]=(ULONG)((end-start)*1000000/freq);sum+=submit[n];sumdone+=complete[n];
  after_return[n]=(ULONG)((end-returned)*1000000/freq);sumafter+=after_return[n];
  if(length==512){short_count++;short_us+=submit[n];}else{long_count++;long_us+=submit[n];}
  for(ULONG i=0;i<length;i++)if(buffer[i]!=pattern(offset+i)){mismatch++;break;}
 }
 ULONGLONG loop_end=KeQueryPerformanceCounter();
 qsort(after_return,READS,sizeof(ULONG),cmp);qsort(submit,READS,sizeof(ULONG),cmp);qsort(complete,READS,sizeof(ULONG),cmp);
 tap_comment("completion-policy mode=%s repeat=%u phase=%u pages=%lu reads=%u pending=%lu elapsed_ms=%lu submit_us_total=%lu p50=%lu p95=%lu max=%lu completion_us_total=%lu p50=%lu p95=%lu max=%lu zero_wait=%lu noyield_wait=%lu",mode_name[mode],repeat,phase,pages,READS,pending,GetTickCount()-before_tick,(ULONG)sum,submit[READS/2],submit[READS*95/100],submit[READS-1],(ULONG)sumdone,complete[READS/2],complete[READS*95/100],complete[READS-1],zero,noyield);
 tap_comment("decomposition mode=%s phase=%u repeat=%u loop_us=%lu after_return_us_total=%lu after_return_p50=%lu after_return_p95=%lu pages_end=%lu",mode_name[mode],phase,repeat,(ULONG)((loop_end-loop_start)*1000000/freq),(ULONG)sumafter,after_return[READS/2],after_return[READS*95/100],available());
 tap_comment("wait-policy mode=%s phase=%u repeat=%u waits=%lu success=%lu noyield=%lu user_apc=%lu timeout=%lu other=%lu",mode_name[mode],phase,repeat,waits,zero,noyield,apc_waits,timeouts,other_waits);
 tap_comment("submission state: completed_iosb_at_return=%lu short_reads=%lu short_submit_us=%lu long_reads=%lu long_submit_us=%lu",at_return,short_count,short_us,long_count,long_us);
 regression_check(!mismatch && !errors,"all read data and callback statuses match");
 regression_check(!other_waits && !timeouts,"all waits have expected statuses");
}
int main(void){
 regression_begin();regression_require(NtCreateEvent(&completion_event,NULL,NotificationEvent,FALSE)==STATUS_SUCCESS,"create completion event");data=MmAllocateContiguousMemory(BLOCK+4096);regression_require(data!=NULL,"allocate reusable owned I/O buffer");
 ANSI_STRING name;RtlInitAnsiString(&name,"\\Device\\Harddisk0\\Partition4\\abi-world-stream.bin");OBJECT_ATTRIBUTES attrs={NULL,&name,OBJ_CASE_INSENSITIVE};HANDLE writer=NULL,reader=NULL;
 NTSTATUS status=NtCreateFile(&writer,GENERIC_WRITE|SYNCHRONIZE,&attrs,&io,NULL,0,0,FILE_OVERWRITE_IF,FILE_NON_DIRECTORY_FILE|FILE_SYNCHRONOUS_IO_NONALERT);
 regression_require(status==0,"create isolated partition4 fixture");
 for(ULONG offset=0;offset<FILE_BYTES;offset+=BLOCK){for(ULONG i=0;i<BLOCK;i++)data[i]=pattern(offset+i);LARGE_INTEGER at={.QuadPart=offset};status=NtWriteFile(writer,NULL,NULL,NULL,&io,data,BLOCK,&at);regression_require(status==0 && io.Information==BLOCK,"populate fixture block");}
 regression_require(NtClose(writer)==0,"close fixture writer");
 status=NtCreateFile(&reader,GENERIC_READ|SYNCHRONIZE,&attrs,&io,NULL,0,FILE_SHARE_READ,FILE_OPEN,FILE_NON_DIRECTORY_FILE|FILE_NO_INTERMEDIATE_BUFFERING);
 regression_require(status==0,"open game-shaped async noncached handle");
 for(unsigned r=0;r<6;r++){unsigned order[]={0,1,2,2,1,0};run(reader,0,r,order[r]);}
 unsigned count=0;while(available()>900 && count<1024){ULONG pages=available(),bytes=(pages-900)*4096;if(bytes>262144)bytes=262144;pressure[count]=MmAllocateContiguousMemory(bytes);if(!pressure[count])break;count++;}
 tap_comment("pressure allocations=%u available=%lu",count,available());regression_require(available()<=900,"reach bounded low-memory target");
 for(unsigned r=0;r<6;r++){unsigned order[]={0,1,2,2,1,0};run(reader,1,r,order[r]);}
 while(count)MmFreeContiguousMemory(pressure[--count]);regression_require(NtClose(reader)==0,"close fixture reader");MmFreeContiguousMemory(data);regression_require(NtClose(completion_event)==STATUS_SUCCESS,"close completion event");regression_finish();
}
