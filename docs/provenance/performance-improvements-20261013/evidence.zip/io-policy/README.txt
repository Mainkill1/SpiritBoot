Completion-policy diagnostic; native qualification pending

No kernel, emulator, shared source, product, or Windows environment was changed.
This fixture uses owned synthetic bytes and public kernel APIs. It isolates the
completion/wait policy from the existing stream-timing-probe. It is not a fix.

Build:
  NXDK_DIR=/home/codex/src/nxdk PATH=/home/codex/src/nxdk/bin:$PATH make -C probe -j2
Artifact: probe/completion-policy-probe.iso
Analyze completed serial logs:
  python analyze.py SERIAL.log [ANOTHER.log ...] > results.json

Every phase performs exactly the original 1024 requests, same order, offsets,
512..7680 byte lengths, buffer offsets, pattern bytes, noncached asynchronous
handle, one outstanding read, and 16 MiB Partition4 fixture. It creates and
populates the same abi-world-stream.bin on the disposable overlay. Every byte,
IOSB status/length, and callback count is verified before buffer reuse. The
fixture must run only on the same fresh-overlay recipe as the existing probe.

Modes:
  apc-poll: original NtReadFile APC plus zero-delay alertable KeDelayExecutionThread.
  apc-block: identical NtReadFile APC; alertable delay has a 5-second bound.
  event-block: NtReadFile has a notification event and no APC; bounded nonalertable
    NtWaitForSingleObjectEx observes completion. Event resets before each read.
The block modes fail if completion does not arrive. Each mode retains accepted
submission, completed IOSB at return, exact completion, byte-pattern checks and
per-phase status accounting. Event mode requires zero callbacks. APC modes
require exactly one callback with the original IO_STATUS_BLOCK context.

Order at normal and <=900-page headroom is poll/block/event/event/block/poll.
This repeats each mode and reverses order to expose gross warmup/order effects;
it does not create independent samples. The same open handle and metadata cache
are retained across modes. The pressure allocator matches the original <=900
page policy. Additional event/array storage means normal pages need not match
the old fixture exactly. Compare both BIOSes with THIS unchanged ISO and keep
old campaign timing separate. The original 50us median-submit assertion is
removed: performance is measured, while every semantic assertion remains.

Timing output:
  submit_us_total and quantiles: NtReadFile entry to return.
  completion_us_total and quantiles: NtReadFile entry until required observable
    APC/event completion, including caller wait/scheduling and callback delivery.
  after_return_us_total and quantiles: return until that observable completion.
  loop_us: wall counter around all requests, including data setup/verification,
    event resets, deadline/status checks and timing calls, excluding sorting and
    printing. Legacy elapsed_ms also includes sorting as the original did.
  outside_observed_read_us_approx: loop_us minus sum of rounded completion spans.
All per-read microsecond conversions truncate; totals can differ by up to one
microsecond per sample from raw-tick aggregate conversion. Wait statuses/counts
and pages at phase start/end are printed. No hot-loop serial instrumentation.

None of these intervals is exclusive disk service time. Event versus APC also
changes the completion mechanism itself; the event case is a discriminator, not
a fully equivalent APC benchmark. Poll versus block preserves that mechanism.
An improvement confined to blocking completion would prioritize scheduler/APC
or polling-policy investigation; persistent submit gaps prioritize submission.
Both can coexist. Neither result alone establishes an actual game bottleneck.

Recommended root-run gate: serialized unchanged xemu, fresh overlays/EEPROM,
Complex/current/ current/Complex alternating bracket; verify ROM/ISO/executable
receipts, no recorder, 12 phases per launch, final zero-failure TAP and exit 0.
If testing current APC/MM candidates, retain their ROM identities separately.
Do not average this probe with the prior streaming or GPU replay campaigns.

Read-only source/evidence findings:
- Current VfatTryAsyncRead bypasses data cache, but VfatTryMapRead still reads
  resident FAT metadata through CcMapData. Broad cached-write/read-churn tests do
  not directly attribute this noncached stream gap.
- Earlier storage-cost-agent/CACHE-COST.md already falsifies per-map BCB pool
  churn and lookup scans for the recorded GPU replay (12293 free-list hits;
  12292 same-block hints and one scan). It also documents substantial observer tax.
- VALIDATED-EXTENT-CACHE.md rejects durable extents without raw-write coherence.
- IRP-DWORD-CANDIDATE.md rejects the faster-clear variant because full replay
  regressed; CLASS-SUBMISSION-LEASE.md has no consistent workload improvement.
- PUBLIC-RESIDUAL.md indicates remaining submission/preparation work but cannot
  attribute exclusive cost across unlike callback placements. No speculative
  runtime patch 0117 was made.
