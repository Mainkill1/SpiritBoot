#!/usr/bin/env python3
"""Validate one completed diagnostic serial log and emit comparable phase rows."""
import json
from pathlib import Path
import re
import sys


def analyze(path):
    serial = path.read_text(errors='replace')
    assert not re.search(r'^not ok\b', serial, re.M), 'TAP failure'
    ends = re.findall(r'# checks=(\d+) failures=(\d+)', serial)
    assert len(ends) == 1 and int(ends[0][1]) == 0, 'missing/failed final summary'
    assert re.search(r'^1\.\.' + ends[0][0] + r'\s*$', serial, re.M), 'missing final plan'
    rows = {}
    pattern = (r'completion-policy mode=(\S+) repeat=(\d+) phase=(\d+) pages=(\d+) '
               r'reads=(\d+) pending=(\d+) elapsed_ms=(\d+) submit_us_total=(\d+) '
               r'p50=(\d+) p95=(\d+) max=(\d+) completion_us_total=(\d+) '
               r'p50=(\d+) p95=(\d+) ')
    names = ['repeat', 'phase', 'pages', 'reads', 'pending', 'elapsed_ms',
             'submit_us_total', 'submit_p50', 'submit_p95', 'submit_max',
             'completion_us_total', 'completion_p50', 'completion_p95']
    for match in re.finditer(pattern, serial):
        row = dict(zip(names, map(int, match.groups()[1:])))
        row['mode'] = match.group(1)
        # tap_comment truncates payloads at 191 bytes; do not accept a partial
        # trailing maximum as a complete value. Required totals/quantiles end earlier.
        row['completion_max'] = None
        key = row['phase'], row['repeat']
        assert key not in rows, ('duplicate phase', key)
        rows[key] = row
    for kind in ['decomposition', 'wait-policy']:
        for line in serial.splitlines():
            if '# ' + kind + ' ' not in line:
                continue
            fields = dict(re.findall(r'(\w+)=(\S+)', line))
            key = int(fields['phase']), int(fields['repeat'])
            assert key in rows, ('missing complete timing prefix', key)
            row = rows[key]
            assert fields['mode'] == row['mode']
            assert kind not in row, ('duplicate detail', kind, key)
            row[kind] = {k: int(v) for k, v in fields.items() if k not in ['mode', 'phase', 'repeat']}
    state_rows = re.findall(r'submission state: completed_iosb_at_return=(\d+) short_reads=(\d+) short_submit_us=(\d+) long_reads=(\d+) long_submit_us=(\d+)', serial)
    assert len(state_rows) == len(rows), 'incomplete submission state'
    for key, state in zip(sorted(rows), state_rows):
        rows[key]['submission_state'] = dict(zip(['completed_iosb_at_return', 'short_reads', 'short_submit_us', 'long_reads', 'long_submit_us'], map(int, state)))
        assert rows[key]['submission_state']['short_reads'] == 547
        assert rows[key]['submission_state']['long_reads'] == 477
    order = ['apc-poll', 'apc-block', 'event-block', 'event-block', 'apc-block', 'apc-poll']
    assert set(rows) == {(phase, repeat) for phase in range(2) for repeat in range(6)}, 'incomplete phases'
    for (phase, repeat), row in sorted(rows.items()):
        assert row['mode'] == order[repeat] and row['reads'] == 1024
        waits = row['wait-policy']
        row['zero_wait'] = waits['success']
        row['noyield_wait'] = waits['noyield']
        assert waits['other'] == 0 and waits['timeout'] == 0
        assert waits['waits'] == sum(waits[k] for k in ['success', 'noyield', 'user_apc', 'timeout', 'other'])
        if row['mode'] == 'event-block':
            assert waits['waits'] == waits['success'] == 1024
        if phase:
            assert row['pages'] <= 900, ('pressure target missed', row)
        row['outside_observed_read_us_approx'] = row['decomposition']['loop_us'] - row['completion_us_total']
    return {'log': str(path), 'checks': int(ends[0][0]), 'unavailable_fields': ['completion_max: original 192-byte TAP payload truncation'], 'phases': [rows[k] for k in sorted(rows)]}


if __name__ == '__main__':
    print(json.dumps([analyze(Path(arg)) for arg in sys.argv[1:]], indent=2))
