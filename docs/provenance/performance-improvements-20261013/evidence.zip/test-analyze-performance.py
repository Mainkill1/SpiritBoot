"""Mutation checks for the evidence qualification gates (no native execution)."""
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('analyzer', ROOT/'analyze-performance.py')
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
OLD=ROOT.parent/'full-xiso-comparison-20261013/results'


def log(pattern, root=ROOT/'results'):
    return next(root.glob(pattern+'/serial.log')).read_text()


class Gates(unittest.TestCase):
    def test_real_frozen_logs_parse(self):
        self.assertEqual(len(a.parse_api(log('probe-apc-api-*'))),634)
        self.assertEqual(len(a.parse_micro(log('probe-micro-0-baseline-*'))),40)
        self.assertEqual(len(a.parse_stream(log('probe-paired-stream-timing-0-candidate-*',OLD))),18)
        self.assertEqual(len(a.parse_sync(log('probe-paired-sync-cost-0-candidate-*',OLD))),4)
        self.assertEqual(a.parse_apc(log('probe-combined-apc-*'))['checks'],30)

    def test_missing_campaign_refused(self):
        old=a.ROOT
        with tempfile.TemporaryDirectory() as directory:
            try:
                a.ROOT=Path(directory);(a.ROOT/'results').mkdir()
                with self.assertRaisesRegex(ValueError,'incomplete performance campaign'):
                    a.main()
            finally:a.ROOT=old

    def test_micro_checksum_and_sample_identity_fail_closed(self):
        source=log('probe-micro-0-baseline-*')
        mutations=[source.replace('checksum=811c9dc5','checksum=00000000',1),
                   source.replace('workload=empty sample=1','workload=empty sample=0',1),
                   source.replace('iterations=1000','iterations=999',1)]
        for modified in mutations:
            with self.assertRaises(ValueError):a.parse_micro(modified)

    def test_api_new_failure_or_changed_todo_refused(self):
        source=log('probe-apc-api-*')
        mutations=[source.replace('ok 1 -','not ok 1 -',1),
                   source.replace('io/storage/flush_volume_readonly','io/storage/new_failure'),
                   source.replace('ticks=', 'ticks=-',1)]
        for modified in mutations:
            with self.assertRaises(ValueError):a.parse_api(modified)

    def test_stream_and_sync_incomplete_or_wrong_work_refused(self):
        source=log('probe-paired-stream-timing-0-candidate-*',OLD)
        for modified in [source.replace('reads=1024','reads=1023',1),
                         source.replace('phase=1','phase=0',1)]:
            with self.assertRaises(ValueError):a.parse_stream(modified)
        source=log('probe-paired-sync-cost-0-candidate-*',OLD)
        for modified in [source.replace('successes=32768','successes=32767',1),
                         source.replace('mode=0 sample=1','mode=0 sample=0',1)]:
            with self.assertRaises(ValueError):a.parse_sync(modified)

    def test_apc_timeout_cannot_count_as_pass(self):
        source=log('probe-combined-apc-*')
        with self.assertRaises(ValueError):a.parse_apc(source.replace('status=000000c0','status=00000102',1))

    def test_receipt_requires_exact_artifacts_and_normal_exit(self):
        original=next((ROOT/'results').glob('probe-performance-apc-*'))
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)
            for f in ['serial.log','launch.json','result.json']:shutil.copy2(original/f,p/f)
            a.receipt(p,'combined-apc','combined')
            launch=json.loads((p/'launch.json').read_text(encoding='utf-8-sig'))
            for field in ['biosSha256','exeSha256','probeSha256']:
                bad=dict(launch);bad[field]='0'*64;(p/'launch.json').write_text(json.dumps(bad))
                with self.assertRaises(ValueError):a.receipt(p,'combined-apc','combined')
            (p/'launch.json').write_text(json.dumps(launch))
            result=json.loads((p/'result.json').read_text(encoding='utf-8-sig'))
            result['exited']=False;(p/'result.json').write_text(json.dumps(result))
            with self.assertRaises(ValueError):a.receipt(p,'combined-apc','combined')


    def test_portable_manifest_relocates_paths_but_not_identities(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            data={'schema':1,'results':'runs','build_manifest':'build.json','firmware':'flash.bin',
                  'fixtures':{name:'fixtures/'+name+'.iso' for name in a.FIXTURES}}
            p=root/'inputs.json';p.write_text(json.dumps(data))
            resolved=a.load_inputs(p)
            self.assertEqual(resolved['results'],root/'runs')
            self.assertEqual(resolved['firmware'],root/'flash.bin')
            self.assertEqual(set(resolved['fixtures']),set(a.FIXTURES))
            data['bios_sha256']='0'*64;p.write_text(json.dumps(data))
            with self.assertRaises(ValueError):a.load_inputs(p)

    def test_performance_focus_prefix_is_recognized_before_unknown_prefix(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'probe-performance-apc-20261013-000000').mkdir()
            with self.assertRaisesRegex(ValueError,'paired=0/24 focused=1/1'):
                a.main({'results':root},root/'outputs')


if __name__=='__main__':unittest.main()
