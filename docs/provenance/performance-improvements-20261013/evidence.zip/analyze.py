"""Validate native candidate receipts and compare each of seven matched trials."""
import csv
import json
import re
import statistics as st
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BIOS = {
    'baseline': '1ed234ebaf8e95937225c3002b6eac26257b0f3d1ff8f3d6a3aabd464955fb0b',
    'pin': '0766fa33db26eeafe3e8fb4ae454482fdea41ae3467b2f169a49323deecd8d8d',
    'des': 'cee608a37a28338aed50aae860c649315261ca1022bf86198cfca73e3f76cc04',
}
EXE = '14777b55740706608cdfde97349eefa3d5115ece4c889679c9c8b96641a85f2d'
values, identities, checksums = {}, set(), {}
for path in sorted((ROOT / 'results').glob('probe-micro-*')):
    match = re.match(r'probe-micro-(\d+)-(baseline|pin|des)-', path.name)
    assert match, path
    pair, side = int(match[1]), match[2]
    key = pair, side
    assert key not in values, ('duplicate trial', key)
    launch = json.loads((path / 'launch.json').read_text(encoding='utf-8-sig'))
    result = json.loads((path / 'result.json').read_text(encoding='utf-8-sig'))
    assert result['exited'] and result['exitCode'] == 0, path
    assert launch['session'] != 0 and launch['exeSha256'].lower() == EXE, path
    assert launch['biosSha256'].lower() == BIOS[side], path
    identities.add(launch['probeSha256'].lower())
    log = (path / 'serial.log').read_text(errors='replace')
    assert 'end PASS' in log and not re.search(r'^not ok', log, re.M), path
    frequency = int(re.search(r'PERF-META.*frequency=(\d+)', log)[1])
    workloads = {}
    entries = re.findall(r'PERF workload=(\S+) sample=(\d+) iterations=(\d+) ticks=(\d+) correct=(\d+) checksum=(\S+)', log)
    assert len(entries) == 118, (path, len(entries))
    for name, sample, iterations, ticks, correct, checksum in entries:
        assert correct == '1', (path, name)
        ckey = name, int(sample)
        expected = int(iterations), checksum
        assert checksums.setdefault(ckey, expected) == expected, (path, ckey)
        workloads.setdefault(name, []).append(int(ticks) * 1e6 / frequency / int(iterations))
    assert len(workloads) == 40, path
    values[key] = {name: st.median(samples) for name, samples in workloads.items()}
assert len(identities) == 1, identities
assert set(values) == {(pair, side) for pair in range(7) for side in BIOS}, ('incomplete trials', len(values))
rows = []
for side in ['pin', 'des']:
    for name in sorted(values[0, side]):
        a = [values[p, 'baseline'][name] for p in range(7)]
        b = [values[p, side][name] for p in range(7)]
        rows.append(dict(candidate=side, workload=name, trials=7,
                         baseline_median_us=st.median(a), candidate_median_us=st.median(b),
                         ratio=st.median(b)/st.median(a),
                         baseline_min_us=min(a), baseline_max_us=max(a),
                         candidate_min_us=min(b), candidate_max_us=max(b),
                         faster_pairs=sum(y < x for x, y in zip(a, b)),
                         direction='faster' if max(b)<min(a) else 'slower' if min(b)>max(a) else 'overlap'))
with (ROOT / 'microbenchmarks.csv').open('w', newline='') as out:
    writer = csv.DictWriter(out, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps({'trials':len(values), 'fixture':list(identities),
                  'targets':[r for r in rows if (r['candidate']=='pin' and r['workload'].startswith('pin-')) or
                             (r['candidate']=='des' and ('des' in r['workload']))]}, indent=2))
