"""Mutation tests for memory evidence gates; no native execution."""
import importlib.util
import json
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('memory',ROOT/'analyze-memory.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

class Gates(unittest.TestCase):
    def setUp(self):
        self.path=next((ROOT/'results').glob('probe-memory-0-baseline-*'))
        self.log=(self.path/'serial.log').read_text()

    def test_exact_sample_contract(self):
        self.assertEqual(len(a.shared.parse_micro(self.log)),40)
        mutations=[self.log.replace('checksum=811c9dc5','checksum=00000000',1),
                   self.log.replace('workload=empty sample=1','workload=empty sample=0',1),
                   self.log.replace('iterations=1000','iterations=999',1),
                   self.log.replace('end PASS','end FAIL'),
                   self.log.replace('ok 1 -','not ok 1 -',1)]
        for log in mutations:
            with self.assertRaises(ValueError):a.shared.parse_micro(log)

    def test_receipt_identity_exit_session_and_duration(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)
            for name in ['launch.json','result.json','serial.log']:shutil.copy2(self.path/name,p/name)
            a.receipt(p,'baseline')
            launch=json.loads((p/'launch.json').read_text(encoding='utf-8-sig'))
            for field,value in [('biosSha256','0'*64),('probeSha256','0'*64),('exeSha256','0'*64),('session',0),('session',True)]:
                bad=dict(launch);bad[field]=value;(p/'launch.json').write_text(json.dumps(bad))
                with self.assertRaises(ValueError):a.receipt(p,'baseline')
            (p/'launch.json').write_text(json.dumps(launch))
            result=json.loads((p/'result.json').read_text(encoding='utf-8-sig'))
            for field,value in [('exited',False),('exitCode',1),('exitCode',False),('elapsedSeconds',0),('elapsedSeconds',float('nan'))]:
                bad=dict(result);bad[field]=value;(p/'result.json').write_text(json.dumps(bad))
                with self.assertRaises(ValueError):a.receipt(p,'baseline')

    def test_missing_campaign_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError,'incomplete memory campaign'):a.analyze(Path(directory))

    def test_overlap_and_order_and_session_refused(self):
        records={};base=datetime(2026,1,1,tzinfo=timezone.utc)
        for pair in range(7):
            order=['baseline','validated'] if pair%2==0 else ['validated','baseline']
            for i,side in enumerate(order):
                start=base+timedelta(seconds=(2*pair+i)*10)
                records[pair,side]=dict(path=f'{pair}-{side}',session=1,started=start,ended=start+timedelta(seconds=5))
        a.validate_intervals(records)
        old=records[0,'validated']['started'];records[0,'validated']['started']=base
        with self.assertRaisesRegex(ValueError,'overlapping'):a.validate_intervals(records)
        records[0,'validated']['started']=old
        records[0,'validated'],records[0,'baseline']=records[0,'baseline'],records[0,'validated']
        with self.assertRaisesRegex(ValueError,'alternate'):a.validate_intervals(records)
        records[0,'validated'],records[0,'baseline']=records[0,'baseline'],records[0,'validated']
        records[0,'baseline']['session']=2
        with self.assertRaisesRegex(ValueError,'session changed'):a.validate_intervals(records)

    def test_seven_pair_statistics(self):
        r=a.stats([1,2,3,4,5,6,7],[.1,.2,.3,.4,.5,.6,.7])
        self.assertEqual((r['baseline_median_us'],r['candidate_median_us']),(4,.4))
        self.assertEqual((r['ratio'],r['faster_pairs'],r['direction']),(.1,7,'faster'))
        with self.assertRaises(ValueError):a.stats([1],[.1])

if __name__=='__main__':unittest.main()
