/* SPDX-License-Identifier: GPL-2.0-or-later
 * Owned data, public read parameters observed in Forza; no game content. */
#include <windows.h>
#include <xboxkrnl/xboxkrnl.h>
#include <stdlib.h>
#include "regression.h"
#define BLOCK 16384
#define READS 1024
#define FILE_BYTES (16*1024*1024)
static unsigned char *data;
static IO_STATUS_BLOCK io;
static volatile ULONG callbacks,errors;
static ULONG wanted;
static PVOID pressure[1024];
static ULONG submit[READS],complete[READS];
static UCHAR pattern(ULONG p){return (UCHAR)(p^(p>>8)^(p>>16));}
static void NTAPI done(DWORD error,DWORD bytes,PVOID context){if(error || bytes!=wanted || context!=&io)errors++;callbacks++;}
static int cmp(const void *a,const void *b){ULONG x=*(ULONG *)a,y=*(ULONG *)b;return x<y?-1:x>y;}
static ULONG available(void){MM_STATISTICS s={.Length=sizeof(s)};return MmQueryStatistics(&s)==0?s.AvailablePages:0;}
static void run(HANDLE file,unsigned phase){
 ULONGLONG freq=KeQueryPerformanceFrequency(),sum=0,sumdone=0;ULONG mismatch=0,pending=0,zero=0,noyield=0;
 ULONG pages=available(),before_tick=GetTickCount();
 ULONG at_return=0, short_count=0, long_count=0, short_us=0, long_us=0;
 for(unsigned n=0;n<READS;n++) {
  ULONG length=n%2==0?512:((n/2)%15+1)*512;
  ULONG offset=((n*7919U)%(FILE_BYTES/BLOCK))*BLOCK+(n%7)*512;
  unsigned char *buffer=data+(n%4)*512;
  memset(buffer,0xcc,length);io.Status=0;io.Information=0;callbacks=0;wanted=length;
  LARGE_INTEGER at={.QuadPart=offset};ULONGLONG start=KeQueryPerformanceCounter();
  NTSTATUS result=NtReadFile(file,NULL,(PIO_APC_ROUTINE)NtUserIoApcDispatcher,(PVOID)done,&io,buffer,length,&at);
  ULONGLONG returned=KeQueryPerformanceCounter();pending+=result==STATUS_PENDING;
  at_return+=io.Status==0 && io.Information==length;
  if(!NT_SUCCESS(result))regression_require(0,"bounded read accepted");
  DWORD deadline=GetTickCount()+5000;
  while(!callbacks && (LONG)(deadline-GetTickCount())>0) {LARGE_INTEGER t={.QuadPart=0};NTSTATUS wait=KeDelayExecutionThread(UserMode,TRUE,&t);zero+=wait==0;noyield+=wait==0x40000024;}
  ULONGLONG end=KeQueryPerformanceCounter();if(callbacks!=1)regression_require(0,"exactly one callback before buffer reuse");
  submit[n]=(ULONG)((returned-start)*1000000/freq);complete[n]=(ULONG)((end-start)*1000000/freq);sum+=submit[n];sumdone+=complete[n];
  if(length==512){short_count++;short_us+=submit[n];}else{long_count++;long_us+=submit[n];}
  for(ULONG i=0;i<length;i++)if(buffer[i]!=pattern(offset+i)){mismatch++;break;}
 }
 qsort(submit,READS,sizeof(ULONG),cmp);qsort(complete,READS,sizeof(ULONG),cmp);
 tap_comment("stream phase=%u pages=%lu reads=%u pending=%lu elapsed_ms=%lu submit_us_total=%lu p50=%lu p95=%lu max=%lu completion_us_total=%lu p50=%lu p95=%lu max=%lu zero_wait=%lu noyield_wait=%lu",phase,pages,READS,pending,GetTickCount()-before_tick,(ULONG)sum,submit[READS/2],submit[READS*95/100],submit[READS-1],(ULONG)sumdone,complete[READS/2],complete[READS*95/100],complete[READS-1],zero,noyield);
 tap_comment("submission state: completed_iosb_at_return=%lu short_reads=%lu short_submit_us=%lu long_reads=%lu long_submit_us=%lu",at_return,short_count,short_us,long_count,long_us);
 regression_check(!mismatch && !errors,"all read data and callback statuses match");
 regression_check(submit[READS/2]<=50,"median submission meets this host qualification budget");
}
int main(void){
 regression_begin();data=MmAllocateContiguousMemory(BLOCK+4096);regression_require(data!=NULL,"allocate reusable owned I/O buffer");
 ANSI_STRING name;RtlInitAnsiString(&name,"\\Device\\Harddisk0\\Partition4\\abi-world-stream.bin");OBJECT_ATTRIBUTES attrs={NULL,&name,OBJ_CASE_INSENSITIVE};HANDLE writer=NULL,reader=NULL;
 NTSTATUS status=NtCreateFile(&writer,GENERIC_WRITE|SYNCHRONIZE,&attrs,&io,NULL,0,0,FILE_OVERWRITE_IF,FILE_NON_DIRECTORY_FILE|FILE_SYNCHRONOUS_IO_NONALERT);
 regression_require(status==0,"create isolated partition4 fixture");
 for(ULONG offset=0;offset<FILE_BYTES;offset+=BLOCK){for(ULONG i=0;i<BLOCK;i++)data[i]=pattern(offset+i);LARGE_INTEGER at={.QuadPart=offset};status=NtWriteFile(writer,NULL,NULL,NULL,&io,data,BLOCK,&at);regression_require(status==0 && io.Information==BLOCK,"populate fixture block");}
 regression_require(NtClose(writer)==0,"close fixture writer");
 status=NtCreateFile(&reader,GENERIC_READ|SYNCHRONIZE,&attrs,&io,NULL,0,FILE_SHARE_READ,FILE_OPEN,FILE_NON_DIRECTORY_FILE|FILE_NO_INTERMEDIATE_BUFFERING);
 regression_require(status==0,"open game-shaped async noncached handle");run(reader,0);
 unsigned count=0;while(available()>900 && count<1024){ULONG pages=available(),bytes=(pages-900)*4096;if(bytes>262144)bytes=262144;pressure[count]=MmAllocateContiguousMemory(bytes);if(!pressure[count])break;count++;}
 tap_comment("pressure allocations=%u available=%lu",count,available());regression_require(available()<=900,"reach bounded low-memory target");run(reader,1);
 while(count)MmFreeContiguousMemory(pressure[--count]);regression_require(NtClose(reader)==0,"close fixture reader");MmFreeContiguousMemory(data);regression_finish();
}
