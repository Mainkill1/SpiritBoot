"""Mutation checks of release qualification; synthetic variants are unit fixtures only."""
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('release',ROOT/'analyze-release.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
BASE=next((ROOT.parent/'perf-improve-20261013/results').glob('probe-performance-api-leaf-performance-0-combined-*/serial.log')).read_text()
STORAGE=next((ROOT/'results').glob('probe-storage-v3-candidate-*/serial.log')).read_text()

def variant(side,clean=False):
    text=BASE
    passing = a.TODOS if side=='complex' else a.FIXED_TODOS if side=='combined' else set()
    for name in passing:
        text=re.sub(r'^not ok (\d+) - '+re.escape(name)+r' # TODO ',r'ok \1 - '+name+' # TODO unexpectedly passing: ',text,flags=re.M)
        text=re.sub(r'(^# LEAF name='+re.escape(name)+r' ticks=\d+) ok=0 todo=1$',r'\1 ok=1 todo=1',text,flags=re.M)
    if clean:
        for name in a.FIXED_TODOS:
            text=re.sub(r'^(ok \d+ - '+re.escape(name)+r') # TODO .*$',r'\1',text,flags=re.M)
            text=re.sub(r'(^# LEAF name='+re.escape(name)+r' ticks=\d+ ok=1) todo=1$',r'\1 todo=0',text,flags=re.M)
    return text

class Gates(unittest.TestCase):
    def test_exact_api_dispositions(self):
        for side,clean in [('baseline',False),('combined',False),('combined',True),('complex',True)]:
            self.assertEqual(len(a.parse_api(variant(side,clean),side,clean)),634)
        with self.assertRaisesRegex(ValueError,'TODO disposition'):a.parse_api(variant('combined'),'baseline')
        with self.assertRaisesRegex(ValueError,'TODO disposition'):a.parse_api(BASE,'combined')
        with self.assertRaises(ValueError):a.parse_api(variant('complex',True),'combined',True)
        with self.assertRaises(ValueError):a.parse_api(variant('combined',True),'complex',True)

    def test_fixed_leaf_cannot_revert_or_join_comparable_set(self):
        self.assertEqual(len(set(a.EXPECTED_LEAVES)-a.TODOS),630)
        source=variant('combined',True)
        name='io/storage/flush_volume_readonly'
        for modified in [re.sub(r'^(ok \d+ - '+re.escape(name)+r')$',r'not \1',source,flags=re.M),
                         source.replace('name='+name,'name=io/storage/unexpected',1),
                         source.replace('ticks=','ticks=-',1),
                         source.replace(' # SKIP ', ' # TODO ',1)]:
            with self.assertRaises(ValueError):a.parse_api(modified,'combined',True)

    def test_storage_real_log_and_mutations(self):
        self.assertEqual(a.parse_storage(STORAGE)['checks'],48)
        for modified in [STORAGE.replace('status=c000007f','status=c000000d',1),
                         STORAGE.replace('free units=0:311273','free units=0:1',1),
                         STORAGE.replace('ok 48 -','not ok 48 -',1),
                         STORAGE.replace('1..48','1..47',1),
                         STORAGE.replace('failures=0','failures=1',1),
                         STORAGE.replace('flush readonly-volume status=00000000','flush readonly-volume status=c0000022',1)]:
            with self.assertRaises(ValueError):a.parse_storage(modified)

    def test_missing_duplicate_and_unknown_campaigns_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            with self.assertRaisesRegex(ValueError,'paired=0/24'):a.main({'results':root},root/'out')
            (root/'probe-performance-api-leaf-performance-0-baseline-20261013-000000').mkdir()
            (root/'probe-performance-api-leaf-performance-0-baseline-20261013-000001').mkdir()
            with self.assertRaisesRegex(ValueError,'duplicate performance trial'):a.main({'results':root},root/'out')
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'probe-final-unrecognized-20261013-000000').mkdir()
            with self.assertRaisesRegex(ValueError,'unrecognized performance receipt'):a.main({'results':root},root/'out')

    def test_receipts_pin_all_artifacts_and_exit(self):
        original=next((ROOT/'results').glob('probe-storage-v3-candidate-*'))
        saved=a.BIOS['combined'];a.BIOS['combined']='8feab7792b73fd840ab717897fb1cbf87d85e1baafc9050ea53191674503a81e'
        try:
            with tempfile.TemporaryDirectory() as d:
                p=Path(d)/original.name;p.mkdir()
                for name in ('serial.log','launch.json','result.json','inputs.json','xemu.toml'):shutil.copyfile(original/name,p/name)
                a.receipt(p,'storage-contract','combined')
                launch=json.loads((p/'launch.json').read_text(encoding='utf-8-sig'))
                for field in ('biosSha256','exeSha256','probeSha256'):
                    bad=dict(launch);bad[field]='0'*64;(p/'launch.json').write_text(json.dumps(bad))
                    with self.assertRaises(ValueError):a.receipt(p,'storage-contract','combined')
                (p/'launch.json').write_text(json.dumps(launch))
                inputs=json.loads((p/'inputs.json').read_text(encoding='utf-8-sig'))
                for field, value in [('memoryMiB',128),('eepromSha256','0'*64),('configSha256','bad'),('backingLength',1)]:
                    bad=dict(inputs);bad[field]=value;(p/'inputs.json').write_text(json.dumps(bad))
                    with self.assertRaises(ValueError):a.receipt(p,'storage-contract','combined')
                (p/'inputs.json').write_text(json.dumps(inputs))
                config=(p/'xemu.toml').read_bytes()
                (p/'xemu.toml').write_bytes(config.replace(b'vsync = false',b'vsync = true'))
                with self.assertRaises(ValueError):a.receipt(p,'storage-contract','combined')
                (p/'xemu.toml').write_bytes(config)
                for field in ('eeprom_path','hdd_path','dvd_path'):
                    modified=re.sub(rb'(?m)^'+field.encode()+rb' = .*$',field.encode()+b" = 'wrong-input.bin'",config)
                    (p/'xemu.toml').write_bytes(modified)
                    with self.assertRaises(ValueError):a.receipt(p,'storage-contract','combined')
                (p/'xemu.toml').write_bytes(config)
                result=json.loads((p/'result.json').read_text(encoding='utf-8-sig'));result['exited']=False
                (p/'result.json').write_text(json.dumps(result))
                with self.assertRaises(ValueError):a.receipt(p,'storage-contract','combined')
        finally:a.BIOS['combined']=saved

    def test_extra_malformed_failure_lines_are_rejected(self):
        for suffix in ['\nBail out! unrecoverable failure\n', '\nnot ok unknown - a failure\n',
                       '\n# LEAF name=unknown ticks=-1 ok=1 todo=0\n']:
            with self.assertRaises(ValueError):a.parse_api(BASE+suffix,'baseline')

    def test_malformed_manifest_removes_stale_success(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); manifest=p/'inputs.json';manifest.write_text('[]')
            for name in a.OUTPUTS:(p/name).write_text('stale successful measurements')
            (p/'performance-report.json').write_text('{"validated":true}')
            result=subprocess.run([sys.executable,str(ROOT/'analyze-release.py'),'--inputs',str(manifest),'--output',str(p)],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
            self.assertFalse(json.loads((p/'performance-report.json').read_text())['validated'])
            self.assertTrue(all(not (p/name).exists() for name in a.OUTPUTS))

    def test_all_new_fixture_identities_are_required(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'inputs.json';data={'schema':1,'results':'runs','build_manifest':'build.json','firmware':'flash.bin','fixtures':{name:'fixtures/'+name+'.iso' for name in a.FIXTURES}}
            p.write_text(json.dumps(data));self.assertEqual(len(a.load_inputs(p)['fixtures']),7)
            del data['fixtures']['storage-contract'];p.write_text(json.dumps(data))
            with self.assertRaises(ValueError):a.load_inputs(p)

if __name__=='__main__':unittest.main()
