$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$s='C:\xemu-lab\incoming\release-qualification-20261013'
if(!(Test-Path ($s+'\write-complete.txt'))){throw 'Earlier qualification gate incomplete'}
if(Get-Process xemu -ErrorAction SilentlyContinue){throw 'Unexpected xemu process'}
$f='C:\xemu-lab\incoming\perf-improve-20261013'
$bioses=@{baseline=($f+'\performance64.bin');combined=($s+'\final64.bin');complex='C:\xemu-lab\XEMU FILES\BIOS\Complex_4627v1.03.bin'}
& ($s+'\run-one.ps1') -Profile final-storage -Bios $bioses['combined'] -Fixture ($s+'\storage-contract-v3.iso') -Port 60700 -TimeoutSeconds 300
& ($s+'\run-one.ps1') -Profile final-api-clean -Bios $bioses['combined'] -Fixture ($s+'\api-leaf-clean.iso') -Port 60702
& ($s+'\run-one.ps1') -Profile reference-api-clean -Bios $bioses['complex'] -Fixture ($s+'\api-leaf-clean.iso') -Port 60704
& ($s+'\run-one.ps1') -Profile performance-apc -Bios $bioses['combined'] -Fixture ($f+'\timer-apc-mode.iso') -Port 60706
$port=60708
foreach($fixture in @('api-leaf-performance','kernel-performance-portable','stream-timing','sync-cost')){
 for($pair=0;$pair -lt 3;$pair++){
  $order=if($pair%2 -eq 0){@('baseline','combined')}else{@('combined','baseline')}
  foreach($side in $order){
   & ($s+'\run-one.ps1') -Profile ('performance-'+$fixture+'-'+$pair+'-'+$side) -Bios $bioses[$side] -Fixture ($f+'\'+$fixture+'.iso') -Port $port
   $port+=2
  }
 }
}
'complete'|Set-Content ($s+'\final-complete.txt')
