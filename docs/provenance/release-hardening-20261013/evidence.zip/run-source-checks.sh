output="artifacts/kernel-host-$VARIANT"
mkdir -p "$output"
i686-w64-mingw32-nm --numeric-sort "$GUEST_BUILD/ntoskrnl/xboxkrnl.unstripped.exe" >"$output/kernel-symbols.txt"
actual_tree=$(git -c "safe.directory=$GUEST_SOURCE" -C "$GUEST_SOURCE" write-tree)
test "$actual_tree" = 694b0e2461558f6a5f7a774fd34c79bd7cdc111e
python3 "$GUEST_SOURCE/tests/host/init-audit-data/check.py" "$output/init-audit-data" >"$output/init-audit-data.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/lto-relink/check.py" "$output/lto-relink" >"$output/lto-relink.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/class-errorlog-layout/check.py" "$GUEST_BUILD" "$output/class-errorlog-layout" >"$output/class-errorlog-layout.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/upper-ram-reservation/check.py" "$output/upper-ram-reservation" >"$output/upper-ram-reservation.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/upper-ram-reservation/check-config.py" "$output/upper-ram-config" >"$output/upper-ram-config.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/warm-stage/check.py" >"$output/warm-stage.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/av-encoder-option/check.py" "$GUEST_SOURCE" "$output/av-encoder-option" >"$output/av-encoder-option.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/av-saved-image/check.py" "$output/av-saved-image" >"$output/av-saved-image.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-writeback-context.py" "$output/cache-writeback-context" >"$output/cache-writeback-context.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-completion-waits.py" "$output/cache-completion-waits" >"$output/cache-completion-waits.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-full-overwrite.py" "$output/cache-full-overwrite" >"$output/cache-full-overwrite.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-lookup-hints.py" "$output/cache-lookup-hints" >"$output/cache-lookup-hints.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/quick-launch-ui/check.py" "$GUEST_SOURCE" "$output/quick-launch-ui" >"$output/quick-launch-ui.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/boot-menu-render/check.py" "$GUEST_SOURCE" "$output/boot-menu-render" >"$output/boot-menu-render.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/reset-frame/check.py" "$output/reset-frame" >"$output/reset-frame.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fault-information/check.py" "$output/fault-information" >"$output/fault-information.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/mdl-pins/check.py" "$output/mdl-pins" >"$output/mdl-pins.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/physical-address/check.py" "$output/physical-address" >"$output/physical-address.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/bootvid-lifetime/check.py" "$output/bootvid-lifetime" >"$output/bootvid-lifetime.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/pciide-pnp-lifetime/check.py" "$output/pciide-pnp-lifetime" >"$output/pciide-pnp-lifetime.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/contig-retry/check.py" "$output/contig-retry" >"$output/contig-retry.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/gpu-instance/check.py" "$output/gpu-instance" >"$output/gpu-instance.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-overwrite.py" "$output/fatx-overwrite" >"$output/fatx-overwrite.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-size-boundaries.py" "$output/fatx-size-boundaries" >"$output/fatx-size-boundaries.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-directory-slots.py" "$output/fatx-directory-slots" >"$output/fatx-directory-slots.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/boot-image/check.py" >"$output/boot-image.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/discardable-sections/check.py" "$output/discardable-sections" >"$output/discardable-sections.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/boot-layout/check.py" "$output/boot-layout" >"$output/boot-layout.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/boot-layout/check-image-bounds.py" "$output/image-bounds" >"$output/image-bounds.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/rom-kernel/check-table.py" "$output/rom-kernel-table" >"$output/rom-kernel-table.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/rom-kernel/check-loader.py" "$output/rom-kernel-loader" >"$output/rom-kernel-loader.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/rom-kernel/check-boot.py" "$output/rom-kernel-boot" >"$output/rom-kernel-boot.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/object-handle-fastpath/check.py" "$output/object-handle-fastpath" >"$output/object-handle-fastpath.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/relocation/check-capacity.py" "$output/relocation-capacity" >"$output/relocation-capacity.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/relocation/check-destinations.py" "$output/relocation-destinations" >"$output/relocation-destinations.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-pin-unwind.py" "$output/cache-pin-unwind" >"$output/cache-pin-unwind.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-pin-arguments.py" "$output/cache-pin-arguments" >"$output/cache-pin-arguments.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-pin-reuse.py" "$output/cache-pin-reuse" >"$output/cache-pin-reuse.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-writeback.py" "$output/cache-writeback" >"$output/cache-writeback.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-shrink.py" "$output/cache-shrink" >"$output/cache-shrink.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-flush-lifetime.py" "$output/cache-flush-lifetime" >"$output/cache-flush-lifetime.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-map-lifetime.py" "$output/cache-map-lifetime" >"$output/cache-map-lifetime.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/cache/check-range-bounds.py" "$output/cache-range-bounds" >"$output/cache-range-bounds.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-fatx32.py" "$output/fatx32" >"$output/fatx32.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-mount-resources.py" "$output/fatx-mount-resources" >"$output/fatx-mount-resources.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-name-bounds.py" "$output/fatx-name-bounds" >"$output/fatx-name-bounds.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-chain-walk.py" "$output/fat-chain-walk" >"$output/fat-chain-walk.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-seek-checkpoints.py" "$output/fatx-seek-checkpoints" >"$output/fatx-seek-checkpoints.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-async-read.py" "$GUEST_SOURCE" "$output/fatx-async-read" >"$output/fatx-async-read.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-async-map.py" "$GUEST_SOURCE" "$output/fatx-async-map" >"$output/fatx-async-map.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-async-coupling.py" "$GUEST_SOURCE" "$output/fatx-async-coupling" >"$output/fatx-async-coupling.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-read-eof.py" "$output/fatx-read-eof" >"$output/fatx-read-eof.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-name-lookup.py" "$output/fatx-name-lookup" >"$output/fatx-name-lookup.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-findfile-upcase.py" "$output/fatx-findfile-upcase" >"$output/fatx-findfile-upcase.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-first-cluster.py" "$output/fatx-first-cluster" >"$output/fatx-first-cluster.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/fatx/check-update-entry-dirty.py" "$output/fatx-update-entry-dirty" >"$output/fatx-update-entry-dirty.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/metadata/check.py" "$output/metadata" >"$output/metadata.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/zero-reuse/check.py" "$output/zero-reuse" >"$output/zero-reuse.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/dma-lifetime/check.py" "$output/dma-lifetime" >"$output/dma-lifetime.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/dma-channel/check.py" "$output/dma-channel" >"$output/dma-channel.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/interrupt-admission/check.py" "$output/interrupt-admission" >"$output/interrupt-admission.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/interrupt-public-abi/check.py" "$output/interrupt-public-abi" >"$output/interrupt-public-abi.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/performance-counter/check.py" "$output/performance-counter" >"$output/performance-counter.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/vm-query-fastpath/check.py" "$GUEST_SOURCE" "$output/vm-query-fastpath" >"$output/vm-query-fastpath.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/immediate-delay/check.py" "$GUEST_SOURCE" "$output/immediate-delay" >"$output/immediate-delay.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/storage-completion/check.py" "$GUEST_SOURCE" "$output/storage-completion" >"$output/storage-completion.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/interrupt-static/check.py" "$GUEST_SOURCE" "$output/interrupt-static" >"$output/interrupt-static.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/interrupt-static/check-built.py" "$GUEST_BUILD/ntoskrnl/xboxkrnl.unstripped.exe" >"$output/interrupt-static-built.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/io-apc-order/check.py" "$output/io-apc-order" >"$output/io-apc-order.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/critical-section/check.py" "$output/critical-section" >"$output/critical-section.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/workqueue/check-fixed-worker-queue.py" "$output/fixed-worker-queue" >"$output/fixed-worker-queue.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/xdvdfs/check.py" "$output/xdvdfs-create" >"$output/xdvdfs-create.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/xdvdfs-directory/check.py" "$output/xdvdfs-directory" >"$output/xdvdfs-directory.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/xdvdfs-masks/check.py" "$output/xdvdfs-masks" >"$output/xdvdfs-masks.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/xdvdfs-read-completion/check.py" "$output/xdvdfs-read-completion" >"$output/xdvdfs-read-completion.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/xbox-rename/check.py" "$GUEST_SOURCE" "$output/xbox-rename" >"$output/xbox-rename.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/video-aspect/check.py" "$GUEST_SOURCE" "$output/video-aspect" >"$output/video-aspect.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/xbe-media/check.py" "$GUEST_SOURCE" "$output/xbe-media" >"$output/xbe-media.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/tap-uart/check.py" "$output/tap-uart" >"$output/tap-uart.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/thread-wait/check.py" "$output/thread-wait" >"$output/thread-wait.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/thread-stack/check.py" "$output/thread-stack" >"$output/thread-stack.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/phase1-thread/check.py" "$output/phase1-thread" >"$output/phase1-thread.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/thread-shadow/check.py" "$output/thread-shadow" >"$output/thread-shadow.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/thread-view/check-registry.py" "$output/thread-view-registry" >"$output/thread-view-registry.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/thread-view/check-wait-adapter.py" "$output/thread-view-wait" >"$output/thread-view-wait.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/thread-view/check-irp.py" "$output/thread-view-irp" >"$output/thread-view-irp.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/dead-stack-policy/check.py" "$output/dead-stack-policy" >"$output/dead-stack-policy.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/zero-alias/check.py" "$output/zero-alias" >"$output/zero-alias.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/pool-refill/check.py" "$output/pool-refill" >"$output/pool-refill.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/pool-size/check.py" "$output/pool-size" >"$output/pool-size.log" 2>&1
"$GUEST_SOURCE/tests/host/clean-room/run.sh" "$output/clean-room" >"$output/clean-room.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/kernel-performance/check.py" "$GUEST_SOURCE" "$output/optimization" --optimized >"$output/optimization.log" 2>&1
mkdir -p "$output/des-baseline/ntoskrnl/xb"
cp "$GUEST_SOURCE/ntoskrnl/xb/crypto.c" "$output/des-baseline/ntoskrnl/xb/crypto.c"
(cd "$output/des-baseline" && git init -q && git apply --reverse --include=ntoskrnl/xb/crypto.c /work/patches/roswell/0116-des-word-rounds.patch)
python3 "$GUEST_SOURCE/tests/host/kernel-performance/des-rounds.py" "$GUEST_SOURCE" "$output/des-baseline" "$output/des-rounds" --optimized >"$output/des-rounds.log" 2>&1
mkdir -p "$output/sha-baseline/sdk/lib/cryptlib" "$output/sha-baseline/ntoskrnl/xb"
cp "$GUEST_SOURCE/sdk/lib/cryptlib/sha1.c" "$output/sha-baseline/sdk/lib/cryptlib/sha1.c"
cp "$GUEST_SOURCE/ntoskrnl/xb/crypto.c" "$output/sha-baseline/ntoskrnl/xb/crypto.c"
(cd "$output/sha-baseline" && git init -q && git apply --reverse --include=sdk/lib/cryptlib/sha1.c /work/patches/roswell/0118-sha-bounded-rounds.patch)
python3 "$GUEST_SOURCE/tests/host/kernel-performance/sha-rounds.py" "$GUEST_SOURCE" "$output/sha-baseline" "$output/sha-rounds" --optimized >"$output/sha-rounds.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/kernel-performance/pins.py" "$GUEST_SOURCE" "$output/pins" --optimized --vector >"$output/pins.log" 2>&1
python3 "$GUEST_SOURCE/tests/host/kernel-performance/pins.py" "$GUEST_SOURCE" "$output/pins-diagnostics" --optimized --vector --diagnostics >"$output/pins-diagnostics.log" 2>&1
