	.file	"<artificial>"
	.text
	.def	_value;	.scl	3;	.type	32;	.endef
_value:
LFB0:
	.cfi_startproc
	movl	$2, %eax
	ret
	.cfi_endproc
LFE0:
	.globl	_entry
	.def	_entry;	.scl	2;	.type	32;	.endef
_entry:
LFB1:
	.cfi_startproc
	jmp	_value
	.cfi_endproc
LFE1:
	.ident	"GCC: (GNU) 13-win32"
