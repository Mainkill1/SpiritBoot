
xboxkrnl.exe:     file format pei-i386


Disassembly of section .text:

00401000 <___crt_xc_end__>:
  401000:	b8 02 00 00 00       	mov    $0x2,%eax
  401005:	c3                   	ret

00401006 <_entry>:
  401006:	eb f8                	jmp    401000 <___crt_xc_end__>

00401008 <__CTOR_LIST__>:
  401008:	ff                   	(bad)
  401009:	ff                   	(bad)
  40100a:	ff                   	(bad)
  40100b:	ff 00                	incl   (%eax)
  40100d:	00 00                	add    %al,(%eax)
	...

00401010 <__DTOR_LIST__>:
  401010:	ff                   	(bad)
  401011:	ff                   	(bad)
  401012:	ff                   	(bad)
  401013:	ff 00                	incl   (%eax)
  401015:	00 00                	add    %al,(%eax)
	...
