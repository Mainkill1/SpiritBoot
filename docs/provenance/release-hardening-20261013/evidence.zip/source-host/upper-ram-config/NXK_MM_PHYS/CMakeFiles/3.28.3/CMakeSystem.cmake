set(CMAKE_HOST_SYSTEM "Linux-6.12.101+deb13-amd64")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "6.12.101+deb13-amd64")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/work/artifacts/final-release64/work-tuql3edc/source/toolchain-gcc.cmake")

set(CMAKE_SYSTEM "Windows")
set(CMAKE_SYSTEM_NAME "Windows")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "i686")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
