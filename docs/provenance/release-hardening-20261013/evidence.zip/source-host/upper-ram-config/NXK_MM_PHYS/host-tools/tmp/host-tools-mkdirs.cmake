# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION 3.5)

file(MAKE_DIRECTORY
  "/work/artifacts/final-release64/work-tuql3edc/source"
  "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools/bin"
  "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools"
  "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools/tmp"
  "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools/src/host-tools-stamp"
  "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools/src"
  "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools/src/host-tools-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools/src/host-tools-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "/work/artifacts/kernel-host-final-release64/upper-ram-config/NXK_MM_PHYS/host-tools/src/host-tools-stamp${cfgdir}") # cfgdir has leading slash
endif()
