file(REMOVE_RECURSE
  "CMakeFiles/nxldr"
  "early-warm.o"
  "loader.o"
  "mem.o"
  "nxldr.bin"
  "nxldr.elf"
  "paging.o"
  "pe.o"
  "startup.o"
  "xz_xz_crc32.o"
  "xz_xz_dec_bcj.o"
  "xz_xz_dec_lzma2.o"
  "xz_xz_dec_stream.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/nxldr.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
