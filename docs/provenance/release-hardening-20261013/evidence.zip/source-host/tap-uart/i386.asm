
/work/artifacts/kernel-host-final-release64/tap-uart/i386.o:     file format elf32-i386


Disassembly of section .text:

00000000 <tap_write_probe>:
   0:	55                   	push   %ebp
   1:	57                   	push   %edi
   2:	56                   	push   %esi
   3:	53                   	push   %ebx
   4:	8b 74 24 14          	mov    0x14(%esp),%esi
   8:	9c                   	pushf
   9:	5d                   	pop    %ebp
   a:	fa                   	cli
   b:	a1 00 00 00 00       	mov    0x0,%eax
			c: R_386_32	.bss
  10:	85 c0                	test   %eax,%eax
  12:	75 46                	jne    5a <tap_write_probe+0x5a>
  14:	31 db                	xor    %ebx,%ebx
  16:	bf f9 03 00 00       	mov    $0x3f9,%edi
  1b:	c7 05 00 00 00 00 01 	movl   $0x1,0x0
  22:	00 00 00 
			1d: R_386_32	.bss
  25:	89 d8                	mov    %ebx,%eax
  27:	89 fa                	mov    %edi,%edx
  29:	ee                   	out    %al,(%dx)
  2a:	b9 fb 03 00 00       	mov    $0x3fb,%ecx
  2f:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
  34:	89 ca                	mov    %ecx,%edx
  36:	ee                   	out    %al,(%dx)
  37:	b8 01 00 00 00       	mov    $0x1,%eax
  3c:	ba f8 03 00 00       	mov    $0x3f8,%edx
  41:	ee                   	out    %al,(%dx)
  42:	89 d8                	mov    %ebx,%eax
  44:	89 fa                	mov    %edi,%edx
  46:	ee                   	out    %al,(%dx)
  47:	b8 03 00 00 00       	mov    $0x3,%eax
  4c:	89 ca                	mov    %ecx,%edx
  4e:	ee                   	out    %al,(%dx)
  4f:	b8 0b 00 00 00       	mov    $0xb,%eax
  54:	ba fc 03 00 00       	mov    $0x3fc,%edx
  59:	ee                   	out    %al,(%dx)
  5a:	0f b6 1e             	movzbl (%esi),%ebx
  5d:	84 db                	test   %bl,%bl
  5f:	74 2a                	je     8b <tap_write_probe+0x8b>
  61:	b9 fd 03 00 00       	mov    $0x3fd,%ecx
  66:	bf f8 03 00 00       	mov    $0x3f8,%edi
  6b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  70:	83 c6 01             	add    $0x1,%esi
  73:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  78:	89 ca                	mov    %ecx,%edx
  7a:	ec                   	in     (%dx),%al
  7b:	a8 20                	test   $0x20,%al
  7d:	74 f9                	je     78 <tap_write_probe+0x78>
  7f:	89 d8                	mov    %ebx,%eax
  81:	89 fa                	mov    %edi,%edx
  83:	ee                   	out    %al,(%dx)
  84:	0f b6 1e             	movzbl (%esi),%ebx
  87:	84 db                	test   %bl,%bl
  89:	75 e5                	jne    70 <tap_write_probe+0x70>
  8b:	55                   	push   %ebp
  8c:	9d                   	popf
  8d:	5b                   	pop    %ebx
  8e:	5e                   	pop    %esi
  8f:	5f                   	pop    %edi
  90:	5d                   	pop    %ebp
  91:	c3                   	ret
