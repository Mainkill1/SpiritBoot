#!/bin/bash
set -euo pipefail
root=/home/codex/xemu-shader-workbench-handoff
product="$root/.scratch/spiritboot-release-hardening-20261013"
for profile in release64 debug64 release128 debug128; do
 variant=${profile%%[0-9]*}
 memory=${profile#"$variant"}
 docker run --rm -v "$product:/work" -v "$root/.scratch/spiritboot-open-pr-pristine-clone:/source:ro" -w /work spiritboot-toolchain python3 scripts/build-firmware.py --source /source --output "artifacts/final-$profile" --variant "$variant" --memory-mib "$memory" > "$root/.scratch/release-qualification-20261013/build-$profile.log" 2>&1
 echo "built $profile"
done
