/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
typedef uint32_t ULONG, PFN_NUMBER, *PPFN_NUMBER;
typedef uintptr_t ULONG_PTR;
typedef size_t SIZE_T, *PSIZE_T;
typedef uint8_t UCHAR, *PUCHAR, BOOLEAN, KIRQL;
typedef int32_t NTSTATUS;
typedef long long LONGLONG;
typedef void VOID, *PVOID, *HANDLE;
typedef struct { LONGLONG QuadPart; } LARGE_INTEGER, *PLARGE_INTEGER;
typedef struct { NTSTATUS Status; SIZE_T Information; } IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;
typedef struct { int signaled; } KEVENT, *PKEVENT;
typedef struct { int StackSize; } DEVICE_OBJECT, *PDEVICE_OBJECT;
typedef struct { ULONG Flags; LARGE_INTEGER CurrentByteOffset; KEVENT Event; } FILE_OBJECT, *PFILE_OBJECT;
typedef void (*PIO_APC_ROUTINE)(void);
typedef int IOP_TRANSFER_TYPE, KPROCESSOR_MODE;
typedef struct { ULONG MajorFunction; PFILE_OBJECT FileObject;
    struct { struct { ULONG Length; LARGE_INTEGER ByteOffset; } Read; } Parameters;
} IO_STACK_LOCATION, *PIO_STACK_LOCATION;
typedef struct { PVOID Buffer, MappedSystemVa; ULONG Length, MdlFlags, Count; PFN_NUMBER Pfns[32]; } MDL, *PMDL;
typedef struct _IRP {
    struct { struct { PFILE_OBJECT OriginalFileObject; PVOID Thread; } Overlay; } Tail;
    int RequestorMode; PIO_STATUS_BLOCK UserIosb; PKEVENT UserEvent; PVOID UserBuffer;
    struct { struct { PIO_APC_ROUTINE UserApcRoutine; PVOID UserApcContext; } AsynchronousParameters; } Overlay;
    ULONG Flags; PMDL MdlAddress; IO_STACK_LOCATION Stack; IO_STATUS_BLOCK IoStatus;
    BOOLEAN PendingReturned; NTSTATUS (*Complete)(PDEVICE_OBJECT, struct _IRP *, PVOID); PVOID Context;
} IRP, *PIRP;
#define IN
#define OUT
#define UNREFERENCED_PARAMETER(x) (void)(x)
#define NTAPI
#define NXK_MM_PHYS 1
#define TRUE 1
#define FALSE 0
#define PAGE_SIZE 4096UL
#define PAGE_SHIFT 12
#define C_ASSERT(c) _Static_assert(sizeof(void *) != 4 || (c), #c)
#define FIELD_OFFSET(t,f) offsetof(t,f)
#define NonPagedPool 0
#define RtlCopyMemory memcpy
#define RtlZeroMemory(p,n) memset(p,0,n)
#define min(a,b) ((a)<(b)?(a):(b))
#define MAXULONG UINT32_MAX
#define MAXLONGLONG LLONG_MAX
#define STATUS_SUCCESS 0
#define STATUS_PENDING 0x103
#define STATUS_INVALID_PARAMETER ((NTSTATUS)0xc000000d)
#define STATUS_INSUFFICIENT_RESOURCES ((NTSTATUS)0xc000009a)
#define STATUS_ACCESS_VIOLATION ((NTSTATUS)0xc0000005)
#define STATUS_IO_DEVICE_ERROR ((NTSTATUS)0xc0000185)
#define STATUS_CANCELLED ((NTSTATUS)0xc0000120)
#define NT_SUCCESS(s) ((s)>=0)
#define NT_ERROR(s) ((s)<0)
#define FILE_WRITE_DATA 2
#define FILE_READ_DATA 1
#define EVENT_MODIFY_STATE 2
#define KernelMode 0
#define Executive 0
#define NotificationEvent 0
#define FO_SYNCHRONOUS_IO 1
#define FO_NO_INTERMEDIATE_BUFFERING 2
#define BooleanFlagOn(v,f) (!!((v)&(f)))
#define IRP_NOCACHE 1
#define IRP_DEFER_IO_COMPLETION 2
#define IRP_XB_SG_COMPLETION 4
#define IRP_WRITE_OPERATION 8
#define IRP_READ_OPERATION 16
#define IRP_MJ_WRITE 4
#define IRP_MJ_READ 3
#define IopWriteTransfer 1
#define IopReadTransfer 0
#define MDL_MAPPED_TO_SYSTEM_VA 1
#define MDL_PAGES_LOCKED 2
#define MmCached 1
#define NormalPagePriority 0
#define MmGetMdlPfnArray(m) ((m)->Pfns)
#define MmGetMdlByteOffset(m) ((ULONG)((uintptr_t)(m)->Buffer & (PAGE_SIZE-1)))
#define MmGetMdlByteCount(m) ((m)->Length)
#define MmGetMdlVirtualAddress(m) ((m)->Buffer)
#define NXPP_BASE PAGE_SIZE
#define NXPP_END UINTPTR_MAX
static DEVICE_OBJECT device = {1};
static FILE_OBJECT file;
static int IoFileObjectType, ExEventObjectType;
static ULONG next_pfn, bad, cases, irps, mdls, refs, locks, allocations;
static int pfn_locked, fail_irp, fail_mdl, fail_pool, pool_calls;
static unsigned map_calls, unmap_calls;
static int fail_map, fail_mdl_once, skew_mdl_once, force_uncached;
static ULONG fake_pde[1024],fake_pte[1024*1024];
#define NXK_PDE_BASE ((uintptr_t)fake_pde)
#define NXK_PTE_BASE ((uintptr_t)fake_pte)
static unsigned mdl_calls;
static size_t allocated_bytes, copy_bytes;
static void measured_copy(void *d,const void *s,size_t n){copy_bytes+=n;memcpy(d,s,n);}
#undef RtlCopyMemory
#define RtlCopyMemory measured_copy
static int delayed, writing;
static NTSTATUS completion_status;
static PIRP pending;
static PMDL paging_mdl;
static PIO_STATUS_BLOCK paging_iosb;
static ULONG pages;
static struct { uintptr_t va; ULONG pte; uintptr_t owner; unsigned pins;
    unsigned char *bytes; void *orphan; } frames[256];
static struct { void *pointer; size_t length; } blocks[32];
static KIRQL MiAcquirePfnLock(void) { assert(!pfn_locked); pfn_locked=1; return 0; }
static void MiReleasePfnLock(KIRQL k) { (void)k; assert(pfn_locked); pfn_locked=0; }
static ULONG *pte_for(uintptr_t va) {
    for (ULONG i=1;i<=pages;i++) if(frames[i].va==va) return &frames[i].pte;
    abort();
}
#define NXPP_PTE(va) (*pte_for(va))
static void NxkPageSupplySetOwner(PFN_NUMBER p, uintptr_t owner) {
    assert(pfn_locked); frames[p].owner=owner;
}
static uintptr_t NxMmGetPhysicalAddress(void *p) {
    uintptr_t va=(uintptr_t)p; return ((*pte_for(va&~(PAGE_SIZE-1))>>12)*PAGE_SIZE)+(va&(PAGE_SIZE-1));
}
static int NxMmIsAddressValid(void *p) { return p!=NULL; }
static int NxkPageSupplyCanPin(PFN_NUMBER p, int unpin) { (void)unpin; return p>0&&p<256; }
static void NxkPageSupplyPin(PFN_NUMBER p, int unpin) {
    assert(pfn_locked); if(unpin){assert(frames[p].pins);--frames[p].pins;} else ++frames[p].pins;
}
static void *ExAllocatePoolWithTag(int kind, size_t n, int tag) {
    (void)kind;(void)tag; if(++pool_calls==fail_pool)return NULL;
    allocated_bytes+=n;
    size_t rounded=(n+PAGE_SIZE-1)&~(PAGE_SIZE-1); if(!rounded)rounded=PAGE_SIZE;
    void *p=NULL;assert(!posix_memalign(&p,1UL<<22,rounded+(1UL<<22)));p=(PUCHAR)p+((1UL<<22)-2*PAGE_SIZE);memset(p,0xcc,rounded);
    unsigned slot;for(slot=0;slot<32;slot++)if(!blocks[slot].pointer)break;
    assert(slot<32);blocks[slot].pointer=p;blocks[slot].length=rounded;++allocations;
    for(size_t off=0;off<rounded;off+=PAGE_SIZE){
        fake_pde[(ULONG)((uintptr_t)p+off)>>22]=force_uncached?0x8b:0x83;
        unsigned f=++next_pfn;assert(f<256);pages=f;frames[f].va=(uintptr_t)p+off;
        frames[f].pte=(f<<12)|3;frames[f].owner=(uintptr_t)&frames[f].pte;
        frames[f].bytes=(unsigned char*)p+off;
    }return p;
}
static void ExFreePoolWithTag(void *p,int tag) {
    (void)tag;unsigned slot;for(slot=0;slot<32;slot++)if(blocks[slot].pointer==p)break;
    assert(slot<32);
    for(unsigned i=1;i<=pages;i++)if(frames[i].va>=(uintptr_t)p&&frames[i].va<(uintptr_t)p+blocks[slot].length){
        PFN_NUMBER current=frames[i].pte>>12;
        assert(!frames[current].pins);assert(frames[current].owner);
        frames[i].va=0;
    }
    blocks[slot].pointer=NULL;--allocations;free((PUCHAR)p-((1UL<<22)-2*PAGE_SIZE));
}
/* Mirrors the page-supply relocation admission contract: owned/unpinned only.
 * Detach old physical storage so a saved MDL reproduces stale DMA behavior. */
static void attempt_relocation(PMDL m) {
    for(unsigned i=0;i<m->Count;i++){
        PFN_NUMBER old=m->Pfns[i];
        if(frames[old].owner&&!frames[old].pins&&!frames[old].orphan){
            ++bad;unsigned fresh=++next_pfn;assert(fresh<256);pages=fresh;
            frames[fresh]=frames[old];frames[fresh].va=0;
            frames[old].pte=(fresh<<12)|3;
            frames[old].orphan=malloc(PAGE_SIZE);assert(frames[old].orphan);
            memcpy(frames[old].orphan,frames[old].bytes,PAGE_SIZE);
            frames[old].bytes=frames[old].orphan;
        }
    }
}
/*
 * Make a window-mapped range immovable (owner cleared) or restore its
 * relocatability (owner recomputed from the window PTE).  Two users:
 * kernel-stack pages (a thread cannot survive its own stack frames
 * being copied out from under the relocation call chain) and buffers
 * pinned for DMA, where the device holds the physical address.
 */
VOID
NxPoolPagesSetMovable(
    IN PVOID BaseAddress,
    IN SIZE_T NumberOfBytes,
    IN BOOLEAN Movable)
{
    ULONG_PTR Va = (ULONG_PTR)BaseAddress & ~((ULONG_PTR)PAGE_SIZE - 1);
    ULONG_PTR End = (ULONG_PTR)BaseAddress + NumberOfBytes;
    KIRQL OldIrql;

    if (Va < NXPP_BASE || Va >= NXPP_END) return;

    OldIrql = MiAcquirePfnLock();
    for (; Va < End; Va += PAGE_SIZE)
    {
        ULONG Pte = NXPP_PTE(Va);
        if (Pte & 0x1)
        {
            NxkPageSupplySetOwner(Pte >> PAGE_SHIFT,
                                  Movable ? (ULONG_PTR)&NXPP_PTE(Va) : 0);
        }
    }
    MiReleasePfnLock(OldIrql);
}

static PMDL IoAllocateMdl(void *p,ULONG n,int a,int b,void *c) {
    (void)a;(void)b;(void)c;++mdl_calls;if(fail_mdl || (fail_mdl_once && mdl_calls==1))return NULL;
    PMDL m=calloc(1,sizeof(*m));assert(m);m->Buffer=(skew_mdl_once && mdl_calls==1)?(PUCHAR)p+1:p;m->Length=n;m->Count=(n+PAGE_SIZE-1)/PAGE_SIZE;++mdls;return m;
}
static void MmBuildMdlForNonPagedPool(PMDL m) {
    m->Count=(m->Length+PAGE_SIZE-1)/PAGE_SIZE;
    for(unsigned i=0;i<m->Count;i++)m->Pfns[i]=NxMmGetPhysicalAddress((char*)m->Buffer+i*PAGE_SIZE)>>12;
    attempt_relocation(m); /* concurrent allocation at physical snapshot */
}
static void IoFreeMdl(PMDL m){assert(!(m->MdlFlags & MDL_MAPPED_TO_SYSTEM_VA));assert(mdls);--mdls;free(m);}
static PIRP IoAllocateIrp(int depth,int quota){(void)depth;(void)quota;if(fail_irp)return NULL;PIRP r=calloc(1,sizeof(*r));assert(r);++irps;return r;}
static void IoFreeIrp(PIRP r){assert(irps);--irps;free(r);}
static PIO_STACK_LOCATION IoGetNextIrpStackLocation(PIRP r){return &r->Stack;}
static void IoSetCompletionRoutine(PIRP r,NTSTATUS (*fn)(PDEVICE_OBJECT,PIRP,PVOID),PVOID c,int a,int b,int d){(void)a;(void)b;(void)d;r->Complete=fn;r->Context=c;}
static NTSTATUS ObReferenceObjectByHandle(HANDLE h,int access,int type,int mode,PVOID *out,void *info){(void)h;(void)access;(void)type;(void)mode;(void)info;*out=&file;++refs;return 0;}
static void ObDereferenceObject(PVOID p){(void)p;assert(refs);--refs;}
static NTSTATUS IopLockFileObject(PFILE_OBJECT f,int mode){(void)f;(void)mode;++locks;return 0;}
static void IopUnlockFileObject(PFILE_OBJECT f){(void)f;assert(locks);--locks;}
static PDEVICE_OBJECT IoGetRelatedDeviceObject(PFILE_OBJECT f){(void)f;return &device;}
static PVOID PsGetCurrentThread(void){return (void*)1;}
static void KeClearEvent(PKEVENT e){e->signaled=0;}
static void IoMarkIrpPending(PIRP r){r->PendingReturned=TRUE;}
static void KeInitializeEvent(PKEVENT e,int type,int value){(void)type;e->signaled=value;}
static unsigned char expected_byte(unsigned offset){return (unsigned char)(offset*13+7);}
static void transfer(PMDL m,int write){
    for(unsigned i=0;i<m->Length;i++){
        unsigned char *b=frames[m->Pfns[i/PAGE_SIZE]].bytes+i%PAGE_SIZE;
        if(write){if(*b!=expected_byte(i))++bad;}else *b=expected_byte(i);
    }
}
static void finish_irp(PIRP r){
    if(r->MdlAddress){attempt_relocation(r->MdlAddress);transfer(r->MdlAddress,writing);}
    r->IoStatus.Status=completion_status;r->IoStatus.Information=NT_SUCCESS(completion_status)&&r->MdlAddress?r->MdlAddress->Length:0;
    IO_STATUS_BLOCK result=r->IoStatus;PIO_STATUS_BLOCK iosb=r->UserIosb;
    r->Complete(&device,r,r->Context);*iosb=result;
    if(locks)IopUnlockFileObject(&file);
    ObDereferenceObject(&file);IoFreeIrp(r);
}
NTSTATUS IopPerformSynchronousRequest(PDEVICE_OBJECT d,PIRP r,PFILE_OBJECT f,BOOLEAN a,int mode,BOOLEAN sync,IOP_TRANSFER_TYPE t){
    (void)d;(void)f;(void)a;(void)mode;(void)sync;(void)t;
    if(delayed){r->PendingReturned=TRUE;pending=r;return STATUS_PENDING;}
    finish_irp(r);return completion_status;
}
static __attribute__((unused)) PVOID MmMapLockedPagesSpecifyCache(PMDL m,int mode,int cache,void *base,int bugcheck,int priority){
    (void)mode;(void)cache;(void)base;(void)bugcheck;(void)priority;
    ++map_calls;if(fail_map)return NULL;
    assert(m->MdlFlags & MDL_PAGES_LOCKED);m->MappedSystemVa=m->Buffer;
    m->MdlFlags|=MDL_MAPPED_TO_SYSTEM_VA;return m->MappedSystemVa;
}
static void MmUnmapLockedPages(PVOID p,PMDL m){
    assert(p==m->MappedSystemVa);assert(m->MdlFlags & MDL_MAPPED_TO_SYSTEM_VA);
    ++unmap_calls;m->MdlFlags &= ~MDL_MAPPED_TO_SYSTEM_VA;m->MappedSystemVa=NULL;
}
/* SPDX-License-Identifier: GPL-2.0-or-later
 * Xbox FILE_SEGMENT_ELEMENT is a four-byte page pointer (public nxdk ABI).
 * One owned IRP retains the segments through completion. Synchronous writes
 * can use caller PFNs; reads and pending writes retain the bounce snapshot.
 * Native I/O manager handles pending, event/APC, cancellation and file locking.
 */

typedef union _XB_FILE_SEGMENT_ELEMENT {
    PVOID Buffer;
    ULONG Alignment;
} XB_FILE_SEGMENT_ELEMENT, *PXB_FILE_SEGMENT_ELEMENT;
C_ASSERT(sizeof(XB_FILE_SEGMENT_ELEMENT) == 4);
#define SG_TAG 'gSbX'
typedef struct _XB_SG_PAGE { PVOID Buffer; PFN_NUMBER Pfn; } XB_SG_PAGE;
typedef struct _XB_SG_REQUEST {
    PVOID Allocation;
    PUCHAR Bounce;
    ULONG Count, Length;
    BOOLEAN Write, BounceProtected, Direct;
    XB_SG_PAGE Pages[1];
} XB_SG_REQUEST;
extern NTSTATUS NTAPI IopPerformSynchronousRequest(PDEVICE_OBJECT, PIRP,
    PFILE_OBJECT, BOOLEAN, KPROCESSOR_MODE, BOOLEAN, IOP_TRANSFER_TYPE);

/* Mapping a non-WB source as WB would create a conflicting cache alias.
 * Xbox has fixed PAT indices: require index zero on the caller's live map. */
static BOOLEAN XbSgPageIsWriteBack(PVOID Page)
{
    ULONG va = (ULONG)(ULONG_PTR)Page;
    ULONG pde = *(volatile ULONG *)(NXK_PDE_BASE + (va >> 22) * sizeof(ULONG));
    ULONG pte;
    if ((pde & 0x19) != 1) return FALSE;
    if (pde & 0x80) return (pde & 0x1000) == 0;
    pte = *(volatile ULONG *)(NXK_PTE_BASE + (va >> PAGE_SHIFT) * sizeof(ULONG));
    return (pte & 0x99) == 1;
}

static VOID XbSgFreeMdl(PMDL Mdl)
{
    if (Mdl->MdlFlags & MDL_MAPPED_TO_SYSTEM_VA)
        MmUnmapLockedPages(Mdl->MappedSystemVa, Mdl);
    IoFreeMdl(Mdl);
}

/* All caller frames have already been validated and pinned. Establish the
 * CPU mapping before dispatch, so failure can still select the bounce route. */
static PMDL XbSgDirectWriteMdl(XB_SG_REQUEST *Request)
{
    PMDL mdl;
    PPFN_NUMBER pfns;
    ULONG i;
    for (i = 0; i < Request->Count; ++i)
        if (!XbSgPageIsWriteBack(Request->Pages[i].Buffer)) return NULL;
    mdl = IoAllocateMdl(Request->Pages[0].Buffer, Request->Length,
                        FALSE, FALSE, NULL);
    if (!mdl) return NULL;
    if (MmGetMdlByteOffset(mdl) != 0 ||
        MmGetMdlByteCount(mdl) != Request->Length) {
        IoFreeMdl(mdl);
        return NULL;
    }
    pfns = MmGetMdlPfnArray(mdl);
    for (i = 0; i < Request->Count; ++i) pfns[i] = Request->Pages[i].Pfn;
    mdl->MdlFlags |= MDL_PAGES_LOCKED;
    if (!MmMapLockedPagesSpecifyCache(mdl, KernelMode, MmCached,
                                      NULL, FALSE, NormalPagePriority)) {
        IoFreeMdl(mdl);
        return NULL;
    }
    return mdl;
}

static VOID XbSgRelease(XB_SG_REQUEST *Request)
{
#ifdef NXK_MM_PHYS
    KIRQL irql = MiAcquirePfnLock();
    ULONG i;
    for (i = 0; i < Request->Count; ++i)
        NxkPageSupplyPin(Request->Pages[i].Pfn, TRUE);
    MiReleasePfnLock(irql);
#endif
    if (Request->BounceProtected)
        NxPoolPagesSetMovable(Request->Bounce, Request->Length, TRUE);
    if (Request->Allocation) ExFreePoolWithTag(Request->Allocation, SG_TAG);
    ExFreePoolWithTag(Request, SG_TAG);
}
static NTSTATUS NTAPI XbSgCompletion(PDEVICE_OBJECT Device, PIRP Irp, PVOID Context)
{
    XB_SG_REQUEST *r = Context;
    ULONG i, copied = 0, bytes = (ULONG)Irp->IoStatus.Information;
    UNREFERENCED_PARAMETER(Device);
    if (bytes > r->Length) {
        Irp->IoStatus.Status = STATUS_IO_DEVICE_ERROR;
        Irp->IoStatus.Information = bytes = 0;
    }
    if (!r->Write && !NT_ERROR(Irp->IoStatus.Status))
        for (i = 0; copied < bytes; ++i) {
            ULONG chunk = min(PAGE_SIZE, bytes - copied);
            RtlCopyMemory(r->Pages[i].Buffer, r->Bounce + copied, chunk);
            copied += chunk;
        }
    /* Retire the mapping before its MDL and caller-frame pins. */
    if (Irp->MdlAddress) { XbSgFreeMdl(Irp->MdlAddress); Irp->MdlAddress = NULL; }
    Irp->UserBuffer = NULL;
    XbSgRelease(r);
    if (Irp->PendingReturned) IoMarkIrpPending(Irp);
    return STATUS_SUCCESS;
}
static NTSTATUS XbScatterGather(BOOLEAN Write, HANDLE FileHandle, HANDLE Event,
    PIO_APC_ROUTINE ApcRoutine, PVOID ApcContext, PIO_STATUS_BLOCK Iosb,
    PXB_FILE_SEGMENT_ELEMENT Segments, ULONG Length, PLARGE_INTEGER ByteOffset)
{
    PFILE_OBJECT file = NULL;
    PKEVENT event = NULL;
    PDEVICE_OBJECT device;
    PIRP irp = NULL;
    PIO_STACK_LOCATION stack;
    XB_SG_REQUEST *r = NULL;
    LARGE_INTEGER offset;
    NTSTATUS status;
    BOOLEAN synchronous, locked = FALSE;
    ULONG count, i, copied;
    if (Iosb == NULL || (Length && Segments == NULL)) return STATUS_INVALID_PARAMETER;
    status = ObReferenceObjectByHandle(FileHandle,
        Write ? FILE_WRITE_DATA : FILE_READ_DATA, IoFileObjectType, KernelMode,
        (PVOID *)&file, NULL);
    if (!NT_SUCCESS(status)) goto fail;
    synchronous = BooleanFlagOn(file->Flags, FO_SYNCHRONOUS_IO);
    if (!(file->Flags & FO_NO_INTERMEDIATE_BUFFERING) ||
        (!synchronous && ByteOffset == NULL) || Length > MAXULONG - PAGE_SIZE) {
        status = STATUS_INVALID_PARAMETER; goto fail;
    }
    if (Event) {
        status = ObReferenceObjectByHandle(Event, EVENT_MODIFY_STATE,
            ExEventObjectType, KernelMode, (PVOID *)&event, NULL);
        if (!NT_SUCCESS(status)) goto fail;
    }
    if (synchronous) {
        status = IopLockFileObject(file, KernelMode);
        if (!NT_SUCCESS(status)) goto fail;
        locked = TRUE;
    }
    offset = ByteOffset ? *ByteOffset : file->CurrentByteOffset;
    if (offset.QuadPart == -2 && synchronous) offset = file->CurrentByteOffset;
    if (offset.QuadPart < 0 && !(Write && offset.QuadPart == -1)) {
        status = STATUS_INVALID_PARAMETER; goto fail;
    }
    if (offset.QuadPart >= 0 && offset.QuadPart > MAXLONGLONG - Length) {
        status = STATUS_INVALID_PARAMETER; goto fail;
    }
    count = (Length + PAGE_SIZE - 1) >> PAGE_SHIFT;
    r = ExAllocatePoolWithTag(NonPagedPool,
        FIELD_OFFSET(XB_SG_REQUEST, Pages) + count * sizeof(XB_SG_PAGE), SG_TAG);
    if (!r) { status = STATUS_INSUFFICIENT_RESOURCES; goto fail; }
    RtlZeroMemory(r, FIELD_OFFSET(XB_SG_REQUEST, Pages));
    r->Write = Write; r->Length = Length;
    for (i = 0; i < count; ++i) {
        PVOID page;
        if (!NxMmIsAddressValid(&Segments[i]) ||
            !NxMmIsAddressValid((PUCHAR)&Segments[i] + sizeof(Segments[i]) - 1)) {
            status = STATUS_ACCESS_VIOLATION; goto fail;
        }
        page = (PVOID)((ULONG_PTR)Segments[i].Buffer & ~(PAGE_SIZE - 1));
        KIRQL pfnIrql;
        PFN_NUMBER pfn;
        if (page == NULL || !NxMmIsAddressValid(page) ||
            !NxMmIsAddressValid((PUCHAR)page + PAGE_SIZE - 1)) {
            status = STATUS_ACCESS_VIOLATION; goto fail;
        }
        pfnIrql = MiAcquirePfnLock();
        pfn = NxMmGetPhysicalAddress(page) >> PAGE_SHIFT;
#ifdef NXK_MM_PHYS
        if (!NxkPageSupplyCanPin(pfn, FALSE)) {
            MiReleasePfnLock(pfnIrql); status = STATUS_INVALID_PARAMETER; goto fail;
        }
        NxkPageSupplyPin(pfn, FALSE);
#endif
        r->Pages[i].Buffer = page; r->Pages[i].Pfn = pfn; ++r->Count;
        MiReleasePfnLock(pfnIrql);
    }
    device = IoGetRelatedDeviceObject(file);
    irp = IoAllocateIrp(device->StackSize, FALSE);
    if (!irp) { status = STATUS_INSUFFICIENT_RESOURCES; goto fail; }
    /* Keep small writes on the bounce route; qualify direct mapping at 64 KiB+. */
    if (Write && synchronous && Length >= 16 * PAGE_SIZE) {
        irp->MdlAddress = XbSgDirectWriteMdl(r);
        r->Direct = irp->MdlAddress != NULL;
    }
    if (!r->Direct) {
        r->Allocation = ExAllocatePoolWithTag(NonPagedPool, Length + PAGE_SIZE, SG_TAG);
        if (!r->Allocation) { status = STATUS_INSUFFICIENT_RESOURCES; goto fail; }
        r->Bounce = (PUCHAR)(((ULONG_PTR)r->Allocation + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1));
        /* The MDL records physical frames, not a relocatable virtual buffer.
         * Establish ownership before its snapshot and retain it through DMA. */
        if (Length) {
            NxPoolPagesSetMovable(r->Bounce, Length, FALSE);
            r->BounceProtected = TRUE;
        }
        if (Write)
            for (i = 0, copied = 0; copied < Length; ++i) {
                ULONG chunk = min(PAGE_SIZE, Length - copied);
                RtlCopyMemory(r->Bounce + copied, r->Pages[i].Buffer, chunk); copied += chunk;
            }
    }
    irp->Tail.Overlay.OriginalFileObject = file;
    irp->Tail.Overlay.Thread = PsGetCurrentThread();
    irp->RequestorMode = KernelMode;
    irp->UserIosb = Iosb; irp->UserEvent = event;
    irp->UserBuffer = r->Direct ? irp->MdlAddress->MappedSystemVa : r->Bounce;
    irp->Overlay.AsynchronousParameters.UserApcRoutine = ApcRoutine;
    irp->Overlay.AsynchronousParameters.UserApcContext = ApcContext;
    irp->Flags = IRP_NOCACHE | IRP_DEFER_IO_COMPLETION | IRP_XB_SG_COMPLETION |
                 (Write ? IRP_WRITE_OPERATION : IRP_READ_OPERATION);
    if (Length && !r->Direct) {
        irp->MdlAddress = IoAllocateMdl(r->Bounce, Length, FALSE, FALSE, NULL);
        if (!irp->MdlAddress) { status = STATUS_INSUFFICIENT_RESOURCES; goto fail; }
        MmBuildMdlForNonPagedPool(irp->MdlAddress);
    }
    stack = IoGetNextIrpStackLocation(irp);
    stack->MajorFunction = Write ? IRP_MJ_WRITE : IRP_MJ_READ;
    stack->FileObject = file;
    stack->Parameters.Read.Length = Length;
    stack->Parameters.Read.ByteOffset = offset;
    IoSetCompletionRoutine(irp, XbSgCompletion, r, TRUE, TRUE, TRUE);
    if (event) KeClearEvent(event);
    KeClearEvent(&file->Event);
    /* Ownership transfers to the IRP/completion, including FO/event refs.
     * Async returns dispatch status, never waits on the shared FO event. */
    return IopPerformSynchronousRequest(device, irp, file, TRUE, KernelMode,
        synchronous, Write ? IopWriteTransfer : IopReadTransfer);
fail:
    if (irp) { if (irp->MdlAddress) XbSgFreeMdl(irp->MdlAddress); IoFreeIrp(irp); }
    if (r) XbSgRelease(r);
    if (locked) IopUnlockFileObject(file);
    if (event) ObDereferenceObject(event);
    if (file) ObDereferenceObject(file);
    Iosb->Status = status; Iosb->Information = 0;
    return status;
}
NTSTATUS NTAPI XeNtReadFileScatter(HANDLE f, HANDLE e, PIO_APC_ROUTINE a,
    PVOID c, PIO_STATUS_BLOCK s, PXB_FILE_SEGMENT_ELEMENT p, ULONG n, PLARGE_INTEGER o)
{ return XbScatterGather(FALSE, f, e, a, c, s, p, n, o); }
NTSTATUS NTAPI XeNtWriteFileGather(HANDLE f, HANDLE e, PIO_APC_ROUTINE a,
    PVOID c, PIO_STATUS_BLOCK s, PXB_FILE_SEGMENT_ELEMENT p, ULONG n, PLARGE_INTEGER o)
{ return XbScatterGather(TRUE, f, e, a, c, s, p, n, o); }
static NTSTATUS page_io(PMDL m,PIO_STATUS_BLOCK iosb,int write){
    paging_mdl=m;paging_iosb=iosb;writing=write;
    if(delayed)return STATUS_PENDING;
    attempt_relocation(m);transfer(m,write);iosb->Status=completion_status;iosb->Information=NT_SUCCESS(completion_status)?m->Length:0;return completion_status;
}
static NTSTATUS IoSynchronousPageWrite(PFILE_OBJECT f,PMDL m,PLARGE_INTEGER o,PKEVENT e,PIO_STATUS_BLOCK i){(void)f;(void)o;(void)e;return page_io(m,i,1);}
static NTSTATUS IoPageRead(PFILE_OBJECT f,PMDL m,PLARGE_INTEGER o,PKEVENT e,PIO_STATUS_BLOCK i){(void)f;(void)o;(void)e;return page_io(m,i,0);}
static NTSTATUS KeWaitForSingleObject(PKEVENT e,int reason,int mode,int alert,void *timeout){(void)e;(void)reason;(void)mode;(void)alert;(void)timeout;attempt_relocation(paging_mdl);transfer(paging_mdl,writing);paging_iosb->Status=completion_status;paging_iosb->Information=NT_SUCCESS(completion_status)?paging_mdl->Length:0;return 0;}

static NTSTATUS
NxcPagingIo(
    IN PFILE_OBJECT FileObject,
    IN PVOID Buffer,
    IN LONGLONG Offset,
    IN ULONG Length,
    IN BOOLEAN Write,
    OUT PSIZE_T Transferred)
{
    PMDL Mdl;
    KEVENT Event;
    IO_STATUS_BLOCK Iosb;
    LARGE_INTEGER Off;
    NTSTATUS Status;

    *Transferred = 0;

    Mdl = IoAllocateMdl(Buffer, Length, FALSE, FALSE, NULL);
    if (Mdl == NULL) return STATUS_INSUFFICIENT_RESOURCES;
    /* Protect physical frames before the MDL snapshots them, not merely
     * before dispatch: relocation between those steps also invalidates DMA. */
    NxPoolPagesSetMovable(Buffer, Length, FALSE);
    MmBuildMdlForNonPagedPool(Mdl);

    Off.QuadPart = Offset;
    KeInitializeEvent(&Event, NotificationEvent, FALSE);
    Iosb.Status = STATUS_SUCCESS;
    Iosb.Information = 0;

    if (Write)
        Status = IoSynchronousPageWrite(FileObject, Mdl, &Off, &Event, &Iosb);
    else
        Status = IoPageRead(FileObject, Mdl, &Off, &Event, &Iosb);

    if (Status == STATUS_PENDING)
    {
        KeWaitForSingleObject(&Event, Executive, KernelMode, FALSE, NULL);
        Status = Iosb.Status;
    }

    NxPoolPagesSetMovable(Buffer, Length, TRUE);

    if (Mdl->MdlFlags & MDL_MAPPED_TO_SYSTEM_VA)
        MmUnmapLockedPages(Mdl->MappedSystemVa, Mdl);
    IoFreeMdl(Mdl);

    *Transferred = Iosb.Information;
    return Status;
}

static void reset(void){
    assert(!allocations&&!irps&&!mdls&&!refs&&!locks&&!pfn_locked);
    for(unsigned i=1;i<=pages;i++){assert(!frames[i].pins);free(frames[i].orphan);}
    memset(frames,0,sizeof(frames));pages=next_pfn=0;pool_calls=0;fail_pool=fail_mdl=fail_irp=delayed=fail_map=0;map_calls=unmap_calls=mdl_calls=0;fail_mdl_once=skew_mdl_once=force_uncached=0;allocated_bytes=copy_bytes=0;pending=NULL;completion_status=0;
    file.Flags=FO_NO_INTERMEDIATE_BUFFERING;
}
static void check_scatter(int write,int delay,NTSTATUS outcome,int failure,ULONG length){
    reset();writing=write;delayed=delay;completion_status=outcome;
    UCHAR *caller=ExAllocatePoolWithTag(0,17*PAGE_SIZE,0);memset(caller,0x5a,3*PAGE_SIZE);
    if(write)for(unsigned i=0;i<length;i++)caller[i]=expected_byte(i);
    XB_FILE_SEGMENT_ELEMENT segments[17];
    for(unsigned i=0;i<17;i++)segments[i].Buffer=caller+i*PAGE_SIZE;
    IO_STATUS_BLOCK iosb={0};LARGE_INTEGER offset={0};
    if(failure==1)fail_irp=1;
    if(failure==2)fail_mdl=1;
    if(failure==3)fail_pool=pool_calls+2;
    NTSTATUS s=XbScatterGather(write,(void*)1,NULL,NULL,NULL,&iosb,segments,length,&offset);
    if(failure)assert(s==STATUS_INSUFFICIENT_RESOURCES);
    else{
        if(delay){assert(s==STATUS_PENDING&&pending);if(write)memset(caller,0xee,length);attempt_relocation(pending->MdlAddress);finish_irp(pending);pending=NULL;}
        assert(iosb.Status==outcome);
        if(!write)for(unsigned i=0;i<length;i++)if(caller[i]!=(NT_SUCCESS(outcome)?expected_byte(i):0x5a))++bad;
    }
    assert(allocations==1&&!irps&&!mdls&&!refs&&!locks);
    for(unsigned i=1;i<=pages;i++)assert(!frames[i].pins);
    ExFreePoolWithTag(caller,0);++cases;
}
static void check_paging(int write,int delay,NTSTATUS outcome,int failure){
    reset();writing=write;delayed=delay;completion_status=outcome;
    UCHAR *buffer=ExAllocatePoolWithTag(0,8192,0);for(unsigned i=0;i<8192;i++)buffer[i]=expected_byte(i);
    fail_mdl=failure;SIZE_T transferred=99;NTSTATUS s=NxcPagingIo(&file,buffer,0,8192,write,&transferred);
    assert(s==(failure?STATUS_INSUFFICIENT_RESOURCES:outcome));
    assert(transferred==(failure||!NT_SUCCESS(outcome)?0:8192));assert(!mdls);
    for(unsigned i=0;i<2;i++)assert(frames[NxMmGetPhysicalAddress(buffer+i*PAGE_SIZE)>>12].owner);
    ExFreePoolWithTag(buffer,0);++cases;
}
static void check_sync_work(int failure,int delay,NTSTATUS outcome,ULONG length){
    reset();writing=1;delayed=delay;completion_status=outcome;file.Flags|=FO_SYNCHRONOUS_IO;
    UCHAR *caller=ExAllocatePoolWithTag(0,17*PAGE_SIZE,0);
    for(unsigned i=0;i<17*PAGE_SIZE;i++)caller[i]=expected_byte(i);
    XB_FILE_SEGMENT_ELEMENT segments[17];
    for(unsigned i=0;i<17;i++)segments[i].Buffer=caller+i*PAGE_SIZE;
    IO_STATUS_BLOCK iosb={0};LARGE_INTEGER offset={0};
    allocated_bytes=copy_bytes=0;
    force_uncached=failure==6;
    /* Source attributes must not depend on whether later allocations share a PDE. */
    for(unsigned i=0;i<17;i++)fake_pde[(ULONG)(uintptr_t)(caller+i*PAGE_SIZE)>>22]=force_uncached?0x8b:0x83;
    fail_map=failure==1 || failure==5;fail_mdl_once=failure==2;skew_mdl_once=failure==3;
    fail_irp=failure==4;if(failure==5)fail_pool=pool_calls+2;
    NTSTATUS status=XbScatterGather(1,(void*)1,NULL,NULL,NULL,&iosb,segments,length,&offset);
    if(failure==4 || failure==5){assert(status==STATUS_INSUFFICIENT_RESOURCES);assert(!map_calls || (failure==5 && map_calls==1));}
    else {
        if(delay){assert(status==STATUS_PENDING && pending);finish_irp(pending);pending=NULL;}else assert(status==outcome);
        assert(iosb.Status==outcome && iosb.Information==(NT_SUCCESS(outcome)?length:0));
        if(failure==0 && length>=16*PAGE_SIZE){assert(copy_bytes==0 && allocated_bytes<PAGE_SIZE);assert(map_calls==1 && unmap_calls==1);}
        else {assert(copy_bytes==length && allocated_bytes>=length+PAGE_SIZE);assert(!unmap_calls);}
    }
    for(unsigned i=0;i<17*PAGE_SIZE;i++)assert(caller[i]==expected_byte(i));
    assert(allocations==1&&!irps&&!mdls&&!refs&&!locks);
    for(unsigned i=1;i<=pages;i++)assert(!frames[i].pins);
    ExFreePoolWithTag(caller,0);++cases;
}
static void check_cache_maps(void){
    void *page=(void*)(uintptr_t)0x81234000;
    ULONG di=(ULONG)(uintptr_t)page>>22,pi=(ULONG)(uintptr_t)page>>12;
    for(ULONG c=0;c<8;c++){
        fake_pde[di]=0x83|((c&1)?8:0)|((c&2)?16:0)|((c&4)?0x1000:0);
        assert(XbSgPageIsWriteBack(page)==(c==0));
        fake_pde[di]=3;fake_pte[pi]=3|((c&1)?8:0)|((c&2)?16:0)|((c&4)?128:0);
        assert(XbSgPageIsWriteBack(page)==(c==0));
    }
    fake_pde[di]=0;assert(!XbSgPageIsWriteBack(page));
    fake_pde[di]=3;fake_pte[pi]=0;assert(!XbSgPageIsWriteBack(page));
    memset(fake_pde,0,sizeof(fake_pde));memset(fake_pte,0,sizeof(fake_pte));
    ++cases;
}
int main(void){
    check_cache_maps();

    ULONG lengths[]={512,4096,4608,8192,65536,66048};NTSTATUS outcomes[]={STATUS_SUCCESS,STATUS_IO_DEVICE_ERROR,STATUS_CANCELLED};
    for(unsigned d=0;d<2;d++)for(unsigned o=0;o<3;o++)for(unsigned n=0;n<6;n++)check_sync_work(0,d,outcomes[o],lengths[n]);
    for(unsigned f=1;f<=6;f++)for(unsigned d=0;d<2;d++)check_sync_work(f,d,STATUS_SUCCESS,65536);
    for(unsigned w=0;w<2;w++)for(unsigned d=0;d<2;d++)for(unsigned o=0;o<3;o++)for(unsigned n=0;n<4;n++)check_scatter(w,d,outcomes[o],0,lengths[n]);
    check_scatter(0,0,STATUS_SUCCESS,0,0);check_scatter(1,0,STATUS_SUCCESS,0,0);
    for(unsigned f=1;f<=3;f++)check_scatter(0,0,0,f,4608);
    for(unsigned w=0;w<2;w++)for(unsigned d=0;d<2;d++)for(unsigned o=0;o<3;o++)check_paging(w,d,outcomes[o],0);
    check_paging(0,0,0,1);reset();
    if(bad){fprintf(stderr,"FAIL: %u relocation/payload violations across %u cases\n",bad,cases);return 1;}
    printf("PASS: %u production scatter/paging DMA lifetime cases; protections restored, payload exact\n",cases);return 0;
}
